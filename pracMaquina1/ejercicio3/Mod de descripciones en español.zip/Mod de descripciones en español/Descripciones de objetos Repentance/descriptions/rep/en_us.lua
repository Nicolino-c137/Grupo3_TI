---------------------------------------
----- Basic English descriptions -----
---------------------------------------

-- Last Update: 11.11.2021

-- FORMAT: Item ID | Name| Description
-- '#' = starts new line of text

-- Special character markup:
-- ↑ = Up Arrow  |  ↓ = Down Arrow  |  ! = Warning

local languageCode = "en_us"


local repCollectibles={
	[2] = {"2", "El Ojo Interior", "Disparo triple#↓ {{Tears}} Lágrimas -49%"},
	[5] = {"5", "Mi Reflejo", "Lágrimas con efecto boomerang#↑ +1.5 de rango#↑ +60% de rango adicional#↑ +0.6 de velocidad de disparo#↑ +1 de altura de lágrima"}, -- My Reflection
	[6] = {"6", "Numero Uno", "↑ +1.5 de lágrimas#↓ -1.5 de rango#↓ -20% de rango adicional"}, -- Number One
	[12] = {"12", "Hongo Mágico", "↑ +1 Vida#↑ +0.3 de daño#↑ +50% de multiplicador de daño#↑ +1.5 de rango#↑ +0.3 de velocidad#¡Salud completa!"},
	[13] = {"13", "El Virus", "Contacto tóxico#↑ +0.2 de velocidad"}, -- The Virus
	[14] = {"14", "Furia por Esteroides", "↑ +0.3 de velocidad#↑ +5.25 de rango#↑ +0.5 de altura de disparo"}, -- Roid Rage
	[18] = {"18", "Un Dólar", "+100 monedas"}, -- A Dollar
	[22] = {"22", "Almuerzo", "↑ +1 Vida#Recuperas 1 corazón"}, -- Lunch
	[23] = {"23", "Cena", "↑ +1 Vida#Recuperas 1 corazón"}, -- Dinner
	[24] = {"24", "Postre", "↑ +1 Vida#Recuperas 1 corazón"}, -- Dessert
	[25] = {"25", "Desayuno", "↑ +1 Vida#Recuperas 1 corazón"}, -- Breakfast
	[26] = {"26", "Carne Podrida", "↑ +1 Vida#Recuperas 1 corazón"}, -- Rotten Meat
	[29] = {"29", "Ropa Interior de Mamá", "↑ +5.25 de rango#↑ +0.5 de altura de lágrima#Suelta 3-6 moscas azules"}, -- Moms Underwear
	[30] = {"30", "Tacones de Mamá", "↑ +1.5 de rango#Causas 12 de daño al tocar enemigos"}, -- Mom's Heels
	[31] = {"31", "Labial de Mamá", "↑ +5.25 de rango#↑ +0.5 de altura de lágrima#Suelta 1 corazón aleatorio"}, -- Mom's Lipstick
	[40] = {"40", "¡Kamikaze!", "Explosión en la ubicación del jugador#Causa 185 de daño"}, -- Kamikaze!
	[42] = {"42", "Cabeza Podrida de Bob", "Bomba tóxica lanzable#Causa tu daño + 185#Crea una nube tóxica"}, -- Bob's Rotten Head
	[44] = {"44", "¡Teletransporte!", "Teletransporta a Isaac a una habitación aleatoria#excepto I AM ERROR#Puedes influenciar el lugar moviendote en una dirección"}, -- Teleport
	[45] = {"45", "Delicioso Corazón", "Recupera un corazón rojo#También recupera medio carazón a otros jugadores"}, -- Yum Heart
	[46] = {"46", "Pie de la Suerte", "↑ +1.0 de Suerte#Mayor probabilidad de ganar al apostar#Incrementa recompensas por vencer habitaciones#Convierte algunas píldoras malas en buenas"}, -- Lucky Foot
	[52] = {"52", "Dr. Fetus", "Lágrimas bomba#Cada bomba causa x10 tu daño#Si el resultado es más de 60 de daño, cambia a x5 tu daño + 30#↓ -60% de lágrimas"}, --Dr. Fetus
	[53] = {"53", "Magneto", "Atrae pickups hacia Isaac#Abre cofres remotamente, ignorando daño en cofres con picos"}, -- Magneto
	[55] = {"55", "Ojo de Mamá", "Posibilidad aleatoria de lanzar una lágrima hacia atrás"}, -- Mom's Eye
	[59] = {"59", "El Libro de Belial", "<Objeto no obtenible>"}, -- The Book of Belial (Judas's Birthright Version)
	[62] = {"62", "Encanto del Vampiro", "↑ +0.3 de daño#Recupera medio corazón por cada 13 enemigos asesinados"}, -- Charm of the Vampire
	[64] = {"64", "Rebajas de Steam", "-50% de descuento en las tiendas#Reduce el precio más al obtenerlo varias veces"}, -- Steam Sale
	[67] = {"67", "Hermana Maggy", "Familiar con lágrimas normales#Causa 5 de daño"}, -- Sister Maggy
	[70] = {"70", "Hormonas de crecimiento", "↑ +1.0 de daño#↑ +0.2 de velocidad"}, -- Growth Hormones
	[71] = {"71", "Honguito", "↑ +0.3 de velocidad#↑ +1.5 de rango#↓ Menor tamaño"}, -- Mini Mush
	[72] = {"72", "Rosario", "+3 corazones de alma#↑ 0.5 de lágrimas#La biblia es más común"}, -- Rosary
	[77] = {"77", "Mi Pequeño Unicornio", "Invencibilidad#20 de daño por contacto"}, -- My Little Unicorn
	[78] = {"78", "Libro de Revelaciones", "+1 corazón de alma#El jefe es reemplazado por un jinete al usarlo (si es posible)#↑ +17.5% de probablilidad de habitación angelical/diablo"}, -- Book of Revelations
	[79] = {"79", "La Marca", "↑ +1.0 de daño#↑ +0.2 de velocidad#+1 corazón oscuro"}, -- The Mark
	[80] = {"80", "El Pacto", "↑ +0.5 de daño#↑ +0.7 de lágrimas#+2 corazones oscuros"}, -- The Pact
	[83] = {"83", "El Clavo", "Medio corazón oscuro#↑ +0.7 de daño#↓ -0.18 de velocidad#Causa daño por contacto#Destruye rocas"}, -- The Nail
	[91] = {"91", "Sombrero de Espeleólogo", "Revela hasta 2 habitaciones adyacentes#Revela habitaciones secretas, super secretas y con mini-jefes#Bloquea proyectiles que caen desde arriba"}, -- Spelunker Hat
	[98] = {"98", "La Reliquia", "Suelta 1 corazón de alma cada 7-8 habitaciones"}, -- The Relic
	[101] = {"101", "El Halo", "↑ +1 Vida#↑ +0.3 de daño#↑ +0.2 de lágrimas#↑ +0.38 de rango#↑ +0.3 de velocidad#↑ +0.5 de altura de lágrima"}, -- The Halo
	[106] = {"106", "Sr. Mega", "↑ Daño de bomba x1.85#+5 Bombas"}, -- Mr. Mega
	[110] = {"110", "Contactos de Mamá", "Posibilidad de lágrimas congelantes#↑ +0.38 de rango#↑ +0.5 de altura de lágrima"}, -- Mom's Contacts
	[118] = {"118", "Azufre", "Recarga un láser de sangre que causa daño de contacto#↓ -67% de lágrima"},
	[121] = {"121", "Hongo Raro", "↑ +1 Vida (vacío)#↑ +1.0 de daño#↑ +0.25 de rango#↓ -0.2 de velocidad#↑ +0.5 de altura de lágrima"}, -- Odd Mushroom (Large)
	[123] = {"123", "Manual de Monstruos", "Invoca un familiar aleatorio para el piso actual"}, -- Monster Manual
	[129] = {"129", "Cubo de Manteca", "↑ +2 Vidas#↓ -0.2 de velocidad#Recuperas medio corazón"}, -- Bucket of Lard
	[135] = {"135", "Bolsa I.V.", "Banco de sangre portátil#Medio corazón = 1-2 monedas#1 moneda en modo difícil#0-1 monedas como Keeper"}, --IV Bag
	[138] = {"138", "Estigma", "↑ +1 Vida#↑ +0.3 de daño#Recuperas 1 corazón"}, -- Stigmata
	[139] = {"139", "Bolso de Mamá", "Ahora puedes tener 2 trinkets#Suelta 1 trinket aleatorio"}, -- Mom's Purse
	[140] = {"140", "Maldición de Bob", "Bombas tóxicas#+5 bombas#Las bombas dejan una nube tóxica"}, -- Bob's Curse
	[148] = {"148", "Infestación", "Suelta 2-6 moscas azules al recibir daño"}, -- Infestation
	[147] = {"147", "Pico de Notch", "Destruye rocas y daña a los enemigos al moverlo#Golpear con el pico reduce su carga#Se recarga completamente en el siguiente piso"}, -- Notched Axe
	[149] = {"149", "Ipecac", "Lágrimas explosivas#↑ +40 de daño#↓ -0.2 de velocidad de disparo#↓ -Lágrimas"}, -- Ipecac
	[152] = {"152", "Tecnología 2", "¡Láser permanente extra!#El láser causa 13% de tu daño#↓ -33% de lágrimas"}, -- Technology 2
	[153] = {"153", "Araña Mutante", "¡Disparo cuádruple!#↓ -58% de lágrimas"}, -- Mutant Spider
	[155] = {"155", "El Fisgón", "Flota alrededor de la habitación#Causa 17.1 de daño por contacto#Tus lágrimas del ojo izquierdo causan 34% más de daño"}, -- The Peeper
	[158] = {"158", "Bola de Cristal", "Revela todo el mapa#Suelta una carta aleatoria o 1 corazón de alma#Mientras lo tienes:#↑ +15% de posibilidad de planetario#100% si ignoraste una habitación con objeto"}, -- Crystal Ball
	[169] =	{"169", "Polifemo", "↑ +100% de daño#↑ +4 de daño adicional#↓ -58% de lágrimas"},
	[171] = {"171", "Trasero Arácnido", "Ralentiza a los enemigos por 4 segundos#10 de daño a los enemigos#Los enemigos que mueren por el sueltan arañas azules"}, -- Spider Butt
	[172] = {"172", "Daga de Sacrificio", "Cuchillo orbital#Bloquea disparos enemigos#Causa 112.5 de daño por segundo"}, -- Sacrificial Dagger
	[176] = {"176", "Células madre", "↑ +1 Vida#↑ +0.16 de velocidad de disparo#Recuperas 1 corazón"}, -- Stem Cells
	[178] = {"178", "Agua Bendita", "{{Throwable}} {{ColorOrange}}Lanzable{{CR}} (pulsa 2 veces el botón de disparo)#Derrama un charco en el lugar lanzado"},
	[182] = {"182", "Sagrado Corazón", "Lágrimas dirigidas#↑ +1 Vida#↑ 230% + 1 de daño#↓ -0.4 de lágrimas#↓ -0.25 de velocidad de disparo#↑ +0.5 de rango#↑ +0.75 de altura de lágrima"}, -- Sacred Heart
	[184] = {"184", "Santo Grial", "Vuelo#↑ +1 Vida#Recuperas 1 corazón"}, -- Holy Grail
	[188] = {"188", "Abel", "Refleja tu movimiento#Dispara hacia Isaac#Causa 3.5 de daño por disparo#7.5 de daño si juegas como Caín"}, -- Abel
	[192] = {"192", "Telepatía para Tontos", "Lágrimas dirigidas durante la habitación actual#↑ +3 de rango"}, -- Telepathy for Dummies
	[193] = {"193", "¡CARNE!", "↑ +1 Vida#↑ +0.3 de daño#Recuperas 1 corazón"}, -- MEAT!
	[194] = {"194", "Bola 8 mágica", "↑ +0.16 de velocidad de disparo#+1 carta#+15% de probabilidad de planetario"}, -- Magic 8 Ball
	[197] = {"197", "Jugo de Jesús", "↑ +0.5 de daño#↑ +0.38 de rango#↑ +0.5 de altura de lágrima"}, -- Jesus Juice
	[203] = {"203", "Humbleing Bundle", "Posibilidad de duplicar los pickups que aparezcan"}, -- Humbling Bundle
	[205] = {"205", "Enchufe Afilado", "- medio corazón = Recarga una barra de tu objeto al pulsar Espacio"}, -- Sharp Plug
	[206] = {"206", "Guillotina", "↑ +1 de daño#↑ +0.33 de lágrimas#Tu cabeza se vuelve un orbital#Dispararás desde la cabeza#La cabeza causa 105 de daño por contacto"}, -- Guillotine
	[211] = {"211", "Bebé-araña", "Suelta 3-5 arañas al recibir daño"}, -- Spider Baby
	[214] = {"214", "Anémico", "↑ +1.5 de rango#Derramas sangre al recibir daño"}, -- Anemic
	[218] = {"218", "Placenta", "↑ +1 Vida#Recuperas 1 corazón#Regenera tu salud lentamente"}, -- Placenta
	[222] =	{"222", "Anti-gravedad", "Lágrimas estaticas al mantener el botón de disparo#Al soltarlo, avanzarán en la dirección que fueron disparadas#↑ +2 de lágrimas"}, -- Anti-Gravity
	[224] = {"224", "Cuerpo de Cricket", "↓ -20% de rango#Las lágrimas se dividen en 4 al chocar##↑ +lágrimas (puede pasar el limite permitido)"}, -- Cricket's Body
	[228] = {"228", "Perfume de Mamá", "Posibilidad de disparos tenebrosos#↑ +lágrimas (puede pasar el limite permitido)"}, -- Moms Perfume
	[230] = {"230", "Abaddón", "↑ +1.5 de daño#↑ +0.2 de velocidad#Lágrimas tenebrosas#Convierte todas tus vidas en corazones oscuros#+2 corazones oscuros"}, -- Abaddon
	[232] = {"232", "Cronómetro", "Efecto permanente de lentitud a enemigos#↑ +0.3 de velocidad"}, -- Stop Watch
	[240] = {"240", "Tratamiento Experimental", "↑ Aumenta 4 de tus puntos aleatoriamente ↓reduce otros 2"}, -- Experimental Treatment
	[245] = {"245", "20/20", "Duplica todos tus disparos#↓ -25% de daño"}, -- 20/20
	[248] = {"248", "Mente de Colmena", "Las arañas/moscas azules duplican su daño#Tus familiares araña/mosca son más fuertes"}, -- Hive Mind
	[253] = {"253", "Costra Mágica", "↑ +1 de suerte#↑ +1 Vida#Recuperas 1 corazón"}, -- Magic Scab
	[254] = {"254", "Coágulo", "↑ +1 de daño#↑ +1.5 de rango#!!! Solo se aplica al ojo izquierdo"}, -- Blood Clot
	[256] = {"256", "Bombas Ardientes", "Bombas en llamas#+5 Bombas#Las bombas causan daño por contacto"}, -- Hot Bombs
	[261] = {"261", "Proptosis", "↑ +0.5 de daño#↓ El daño se reduce con la distancia de viaje de la lágrima#Empieza con 300% de daño"}, -- Proptosis
	[262] = {"262", "Hoja 2 faltante", "+1 Corazón oscuro#Si tus corazones se reducen a 1, daña a todos los enemigos en la habitación#Los corazones oscuros duplican su daño"}, -- Missing Page 2
	[263] = {"263", "Runa limpia", "Copia el efecto de tu runa o piedra de alma#Suelta 1 runa al tomarlo"}, -- Clear Rune   (REPENTANCE ITEM)
	[273] = {"273", "Cerebro de Bob ", "Familiar explosivo que se puede lanzar#La explosión causa 100 de daño"}, -- Bob's Brain
	[274] = {"274", "Gran Amigo", "Al recibir daño, obtienes un orbital de medio rango#Causa 150 de daño"}, -- Best Bud
	[275] = {"275", "Mini-azufre", "Familiar con disparos de azufre#Causa 20 de daño"}, -- Lil Brimston
	[276] = {"276", "Corazón de Isaac", "Tu cuerpo es invulnerable#!!! Recibes daño cuando el corazón es atacado#Recarga una lluvia de lágrimas"}, -- Isaac's Heart
	[278] = {"278", "Pordiosero Oscuro", "!!! Convierte:#1,5 corazones rojos en 1 corazón de alma/oscuro, araña, píldora, carta o runa"}, -- Dark Bum
	[280] = {"280", "Sissy Patitas Largas", "Te regala arañas azules en habitaciones hostiles#Encanta a los enemigos al tocarlos"}, -- Sissy Longlegs
	[283] = {"283", "D100", "Cambia todos los pickups, objetos en pedestal y tus objetos#Duplica un pickup aleatorio en la habitación#Reinicia la habitación actual"}, -- D100
	[285] = {"285", "D10", "Cambia todos los enemigos en la habitación#Los cambia por enemigos con la misma salud"}, -- D10
	[287] = {"287", "Libro de Secretos", "Revela parte del mapa#Solo te da efectos en el mapa que no obtuviste"}, -- Book of Secrets
	[288] = {"288", "Caja de Arañas", "Suelta 4-8 arañas azules"}, -- Box of Spiders
	[289] = {"289", "Vela Roja", "Suelta un fuego rojo#La llama dura hasta causar daño 5 veces o 10 segundos"}, -- Red Candle
	[291] = {"291", "¡Flush!", "!!! ¡Mata inmediatamente a enemigos y jefes de popó!#Convierte enemigos en popó#Apaga el fuego#Convierte la lava en suelo sólido"}, -- Flush!
	[292] = {"292", "Biblia Satánica", "+1 Corazón oscuro#Al usarlo antes de luchar con un jefe el objeto del jefe será un trato con el diablo"}, -- Satanic Bible
	[294] = {"294", "Frijol Mantequilla", "Hace retroceder a los enemigos#Los enemigos obtienen 10 de daño al chocar con algo"}, -- Butter Bean
	[295] = {"295", "Dedos Mágicos", "Daña a toda la habitación con tu daño x2 + 10 #Precio: 1 moneda"}, -- Magic Fingers
	[296] = {"296", "Conversor", "!!! Convierte:#1 corazón de alma/oscuro en una vida"}, -- Converter
	[297] = {"297", "Caja de Pandora", "!!! DE UN SOLO USO#!!! Suelta cosas de acuerdo al piso en el que es activado:#S1: 2 Corazones de alma#S2: 2 Llaves y bombas#C1: 1 Objeto de Jefe#C2: S1+C1#P1: 4 Corazones de alma#P2: 30 Monedas#M1: 2 Objetos de Jefe#M2: Biblia#Sheol: 1 Objeto diabólico + corazón oscuro#Cat: 1 Objeto angelical + corazón de alma#Cofre: 1 Moneda#Casa: Llave roja"}, -- Pandora's box
	[300] = {"300", "Aries", "↑ +0.25 de velocidad#Hieres a los enemigos al chocarlos#Evitas daño por contacto al ser más veloz"}, -- Aries
	[307] = {"307", "Capricornio", "↑ +1 Vida / Llave / Bomba / Moneda#↑ +0.5 de daño#↑ +0.1 de velocidad#↑ +0.75 de rango#+Lágrimas"}, -- Capricorn
	[308] = {"308", "Acuario ", "Deja un rastro de lágrimas que daña a los enemigos#El rastro tiene sinergia con los efectos de lágrima"}, -- Aquarius
	[309] =	{"309", "Piscis", "↑ +0.5 de lágrimas#Las lágrimas retroceden más a los enemigos"},
	[310] =	{"310", "Rímel de Eva", "↑ x2 de daño#↓ -33% de lágrimas#↓ -0.5 de velocidad de disparo"},
	[314] = {"314", "Curvas Gruesas", "↑ +1 Vida#↓ -0.4 de velocidad#Recuperas 1 corazón#Puedes destruir rocas"}, -- Thunder Thighs
	[315] = {"315", "Atractor Extraño", "Lágrimas magnéticas#Afecta a enemigos, pickups y trinkets#Serán atraidos a donde aterriza la lágrima"}, -- Strange Attractor
	[320] = {"320", "Unico Amigo de ???", "Mosca controlable#Causa 3.5 de daño por golpe"}, -- ???'s Only Friend
	[326] = {"326", "Respiración de Vida", "Mantén pulsado espacio hasta vaciar la barra de carga y obtener invencibilidad#Caerán rayos de luz a enemigos cuendo te toquen en estado invencible#!!! ¡No lo pulses mucho tiempo!"}, -- Breath of Life
	[328] = {"328", "El Negativo", "↑ +1.0 de daño#Efecto de Necronomicon al recibir daño y tener solo medio corazón rojo o ninguno"}, -- The Negative
	[330] = {"330", "Leche de Soya", "↑ Muchas más lágrimas: (disparo x 5.5)#↓ -80% de daño"}, -- Soy Milk
	[331] = {"331", "Deidad", "Lágrimas dirigidas#↑ +0.93 de daño#↑ +0.5 de rango#↓ -0.6 de lágrimas#↓ -30% de velocidad de disparo#↑ +0.8 de altura de lágrima"}, -- Godhead
	[336] = {"336", "Cebolla Muerta", "Lágrimas espectrales y perforantes#↓ -1.5 de rango#↓ -0.4 de velocidad de disparo"}, -- Dead Onion
	[339] = {"339", "El Gancho", "↑ +1.5 de rango#↑ +0.16 de velocidad de disparo#+1 corazón oscuro#↑ +0.5 de altura de lágrima"}, -- Safety Pin
	[342] = {"342", "Hongo Azul", "↑ +1 Vida#↑ +0.7 de lágrimas#↓ -16% de velocidad de disparo#Recuperas 2 corazones"}, -- Blue Cap
	[344] = {"344", "Caja de Fósforos", "+1 Corazón oscuro#Suelta 2-3 Bombas#Suelta el trinket {{Trinket41}} Fósforo"}, -- Match Book
	[345] = {"345", "Esteroides", "↑ +1.0 de daño#↑ +1.5 de rango#↑ +0.5 de altura de lágrima"}, -- Synthoil
	[346] = {"346", "Un Bocadillo", "↑ +1 Vida#Recupera 2 corazones"}, -- A Snack
	[350] = {"350", "Shock Tóxico", "Todos los enemigos son intoxicados al entrar en una habitación#Eres inmune a nubes tóxicas"}, -- Toxic Shock
	[352] = {"352", "Cañón de Cristal", "Dispara una gran lágrima perforante y espectral ((Daño+1) X 10)#Cuando recibes daño y el cañon se rompe te reduce 2 corazones"}, -- Glass Canon
	[354] = {"354", "Crack Jacks", "↑ +1 Vida#Suelta un trinket aleatorio#Recuperas 1 corazón"}, -- Crack Jacks
	[355] = {"355", "Perlas de Mamá", "↑ +1.25 de rango#↑ +1 de suerte#+1 corazón de alma#↑ +0.5 de altura de lágrima"}, -- Mom's Pearl
	[360] = {"360", "Incubo", "Dispara las mismas lágrimas que Isaac#Causa 100% de tu daño al jugar con Lilith#Causa 75% de tu daño con los demás"}, -- Incubus
	[366] = {"366", "Bombas de Dispersión", "+5 bombas#Causa que tu bomba suelte 4-5 pequeñas bombas al explotar"}, -- Scatter Bombs
	[368] =	{"368", "Epifora", "Aumentan tus lágrimas al disparar en una sola dirección hasta un 200%"},
	[369] = {"369", "Continuo", "↑ +3.0 de rango#↑ +1.5 de altura de lágrima#Las lágrimas viajan a través de las paredes y aparecen en el lado opuesto"}, -- Continuum
	[370] = {"370", "Sr. muñeca", "↑ +0.7 de lágrimas#↑ +1.5 de rango#↑ +0.5 de altura de lágrima#Suelta 3 corazones aleatorios al tomarlo"}, -- Mr. Dolly
	[372] = {"372", "Bebé Recargado", "Probabilidad aleatoria de soltar una mini-batería o congelar a los enemigos en la habitación#Probabilidad de dar una carga a tu objeto activable"}, -- Charged Baby
	[374] = {"374", "Luz Sagrada", "Probabilidad aleatoria de disparar una lágrima sagrada, el cual soltará un rayo celestial#El rayo causa tu daño x3"}, -- Holy Light
	[375] = {"375", "Sombrero Host", "20% de probabilidad de bloquear disparos#Eres inmune a explosiones"}, -- Host hat
	[376] = {"376", "Reponer", "Las tiendas reponen el inventario al comprar algo#Las reposiciones incrementan su precio"}, -- Restock
	[382] = {"382", "Bola Amiga", "Puede lanzarse a enemigos para capturarlos#Al siguiente uso, reaparecerá el mismo enemigo en estado amigable#Al caminar sobre la bola después de capturarlo se recargará por completo"}, -- Friendly Ball
	[384] = {"384", "Mini-gurdy", "Familiar con ataque de embestida#Causa 5-20 de daño dependiendo del tiempo de carga"}, -- Lil Gurdy
	[389] = {"389", "Bolsa de Runas", "Suelta una runa aleatoria cada 7-8 habitaciones#También puede soltar piedras de alma"}, -- Rune Bag
	[393] = {"393", "Beso de serpiente", "Probabilidad aleatoria de disparar lágrimas tóxicas#Intoxicas enemigos al tocarlos#Los enemigos intoxicados por contacto tienen un 20% de probabilidad de soltar corazones oscuros"}, -- Serpent`s Kiss
	[394] = {"394", "En la Mira", "Dispara lágrimas automáticamente hacia la dirección donde está la mira roja#↑ +0.7 de lágrimas#↑ +3.0 de rango#↑ +0.3 de altura de lágrima#Los familiares disparan hacia la mira roja"}, -- Marked
	[395] = {"395", "Tech X", "Tienes la habilidad de recargar y disparar anillos de láser#El daño aumenta con la recarga#100% de daño al completarlo"}, -- Tech X
	[397] = {"397", "Rayo Tractór", "Tus lágrimas viajan siguiendo el rayo de luz, puede cambiar de dirección de acuerdo a tus movimientos#↑ +0.5 de lágrimas#↑ +1.5 de rango#↑ +0.16 de velocidad de disparo#↑ +0.5 de altura de lágrima"},
	[399] = {"399", "Fauces del Vacío", "Después de disparar lágrimas por 3 segundos, una cruz roja aparece en la cabeza de Isaac. Al soltar el botón de disparo suelta un anillo oscuro que daña a los enemigos"}, -- Maw of the Void
	[401] = {"401", "Explosivo", "Probabilidad de disparar lágrimas bomba pegajosas#Las lágrimas pegajosas causan un daño constante"}, -- Explosivo
	[404] = {"404", "Bebé Tira-pedos / Farting Baby", "Bloquea disparos#Si una lágrima lo toca, soltará un pedo que daña, encanta o empuja a los enemigos#El pedo causa 5-6 de daño"}, -- Farting Baby
	[405] = {"405", "Error_crítico", "{{Throwable}} {{ColorOrange}}Lanzable{{CR}} (pulsa 2 veces el botón de disparo)#Cambia los enemigos y pickups que entran en contacto con él"}, -- GB Bug
	[407] = {"407", "Pureza", "↑ Incrementa uno de los puntos de Isaac dependiendo del color del aura a su alrededor#Tienes una nueva aura al recibir daño#{{ColorRed}}Rojo{{CR}} = +4.0 de daño#{{ColorBlue}}Azul{{CR}} = -4 de retraso de lágrima#{{ColorYellow}}Amarillo{{CR}} = +0.5 de velocidad#{{ColorOrange}}Naranja{{CR}} = +3.0 de rango, +1 de altura de lágrima"},
	[408] = {"408", "Athame", "Al recibir daño, un anillo oscuro aparecerá alrededor de Isaac causando daño a los enemigos"}, -- Athame
	[416] = {"416", "Bolsillos Profundos", "Suelta 1-3 monedas si una habitación no te da un premio#Incrementa la capacidad de monedas a 999"}, -- Deep Pockets
	[417] = {"417", "Súcubo", "Va alrededor de la habitación con un aura que causa 7.5-10 de daño a los enemigos#↑ +50% de daño al estar dentro del aura"}, -- Succubus
	[421] = {"421", "Frijol Rojo", "Aplica un efecto de encantamiento a todo enemigo en un rango corto"}, -- Kidney Bean
	[426] = {"426", "Fan Obsesionado", "Imita tus movimientos 0.66 segundos después#Causa 30 de daño por contacto"}, -- Obsessed Fan
	[430] = {"430", "Mosca Papá", "Imita tus movimientos 0.66 segundos después#Dispara a enemigo cercanos con el mismo daño que Isaac"}, -- papa Fly
	[431] = {"431", "Bebé Multidimensional", "Imita tus movimientos 0.66 segundos después#Tus lágrimas que pasan sobre él se duplican y aumentan su velocidad"},
	[437] = {"437", "D7", "Revive a los enemigos, permitiéndote obtener más recompensas en una habitación"}, -- D7
	[440] = {"440", "Piedra de Riñón", "De forma aleatoria, puedes parar de disparar y lanzar una piedra de riñón junto a una lluvia de lágrimas"}, -- Kidney Stone
	[442] = {"442", "Corona del Príncipe Oscuro", "!!! Mientras tienes un solo corazón rojo:#↑ +1.5 de rango#↑ +2.0 de lágrimas#↑ +0.2 de velocidad de disparo#(No funciona con personajes sin corazones rojos)"}, -- Dark Princes Crown
	[444] = {"444", "Lápiz", "Por cada 15 lágrimas disparadas, lanzas un conjunto de lágrimas"}, -- Lead Pencil
	[448] = {"448", "Pedazo de Vidrio", "Al recibir daño, lanzas lágrimas rojas y dejas un rastro de sangre#Recibes daño cada 30 segundos hasta que tomes un corazón rojo"}, -- Shard of Glass
	[451] = {"451", "Tela de Tarot", "Suelta una carta, runa o pickup aleatorio#Duplíca al efecto de las cartas de tarot#Algunas cartas obtienen un efecto extra"}, -- Tarot Cloth
	[453] = {"453", "Fractura Compuesta", "Lágrimas hueso#Tus lágrimas se rompen en 1-3 fragmentos al chocar con algo#↑ +0.38 de rango#↑ +1.0 de altura de lágrima"}, -- Compound Fracture
	[455] = {"455", "Moneda Perdida de Papá", "↑ +0.38 de rango#Suelta una moneda de la suerte"},
	[456] = {"456", "Bocadillo nocturno", "↑ +1 Vida#Recuperas 1 corazón"}, -- Midnight Snack
	[459] = {"459", "Infección Sinusal", "Lágrimas tóxicas pegajosas#Causa tu daño por cada segundo#Se queda pegado por 10 segundos"}, -- Sinus Infection
	[464] = {"464", "Glifo del Equilibrio", "+2 Corazones de alma#Los enemigos campeones sueltan pickups con más frecuencia#La prioridad de pickups se basa en lo que le falta a Isaac"}, -- Glyph of Balance
	[472] = {"472", "Rey Bebé", "Los otros familiares lo siguen y disparan automaticamente a enemigos#Deja de moverse mientras disparas#Se teletransporta hacia ti cuando dejas de disparar"}, -- King Baby
	[474] = {"474", "Cañon de cristal roto", "Se convierte en cañon de cristal al usarlo"}, -- broken Glass Canon
	[489] = {"489", "D infinito", "Efecto de dado al usarlo#Pulsa Ctrl para cambiar de dado"}, -- D Infinity
	[491] = {"491", "Bebé Acido", "Suelta una píldora aleatoria por cada 7 habitaciones#Al usar una píldora daña a los enemigos"}, -- Acid Baby
	[493] = {"493", "Adrenalina", "Por cada medio corazón vacío:#↑ +daño calculado por ((2 * medio corazón faltante) ^ 1.6) * 0.1"}, -- Adrenaline
	[494] = {"494", "Escalera de Jacob", "Las lágrimas sueltan 1 corriente eléctricas al chocar con algo#Las corrientes causan la mitad de tu daño#Las corrientes pueden pasar de enemigo a enemigo"}, -- Jacobs Ladder
	[503] = {"503", "Cuernito", "Probabilidad de disparar lágrimas que invoca la mano de Gran cuerno(Big Horn)#La mano mata instantaneamente a enemigos y daña a jefes"}, -- Little Horn
	[504] = {"504", "Nugget Café", "Suelta una mosca torreta que dispara a enemigos#Causa 3.5 de daño"}, -- Brown Nugget
	[509] = {"509", "Ojo Dispara-lágrimas", "Dispara una lágrima cada 1/3 segundos cuando un enemigo está cerca#Causa 3.5 de daño#Causa 30 de daño por contacto"}, -- Bloodshot Eye
	[517] = {"517", "Bombas Rápidas", "+7 Bombas#Te permite colocar bombas rápidamente#Las bombas no se empuejan entre ellas"}, -- Fast Bombs
	[523] = {"523", "Caja de Mudanza", "Al usarlo, Guarda hasta 6 cosas de la habitación actual#Al usarlo de nuevo suelta todo en el suelo#Esto te permite mover cosas entre habitaciones"}, -- Moving Box
	[524] = {"524", "Tecnología Cero", "Las lágrimas estarán conectadas con electricidad#La electricidad causa 1/3 de tu daño"}, -- Technology Zero
	[531] = {"531", "Hemolacria", "Las lágrimas viajan en forma de arco#Las lágrimas se dividen al chocar con algo#↓ lágrimas#↑ +50% de daño#↑ +1 de daño adicional"}, -- Haemolacria
	[541] = {"541", "Médula", "+1 corazón de hueso#Suelta 3 corazones rojos#Probabilidad de soltar {{Trinket167}} Hueso pulido cuando pierdes un corazón de hueso"}, -- Marrow
	[543] = {"543", "Suelo Santificado", "Suelta una popó blanca cuando recibes daño#(La popó blanca tiene un aura que aumenta tus lágrimas y daño↑, +Lágrimas dirigidas)"}, -- Hallowed Ground
	[549] =	{"549", "Huesos Frágiles", "Remplaza todas tus vidas por 6 corazones de hueso#Al perder un corazón de hueso:#Disparas 8 lágrimas en todas direcciones#↑ +0.4 de lágrimas permanentemente"}, -- Brittle Bones
	[553] = {"553", "Mucormicosis", "Posibilidad de disparar lágrimas en espora pegajosas#Las esporas explotan en 2.5 segundos dañanado e intoxicando a enemigos"}, --  Mucormycosis
	[554] = {"554", "Muy aterrador", "Asusta a los enemigos en un radio corto a Isaac"}, --  2Spooky
	[555] = {"555", "Hoja dorada", "Convierte 5 monedas en +1.2 de daño durante la habitación#Suelta 5 monedas"}, --  Golden Razor
	[556] = {"556", "Sulfuro", "Te da Azufre {{Collectible118}} durante la habitación actual"}, --  Sulfur
	[557] = {"557", "Galleta de la fortuna", "Da a Isaac una predicción, corazón de alma, carta de tarot o trinket"}, --  Fortune Cookie
	[558] = {"558", "Dolor de ojo", "Posibilidad de disparar 1-2 lágrimas extra en direcciones aleatorias"}, --  Eye Sore
	[559] = {"559", "120 Voltios", "Electrifica a enemigos cercanos"}, --  120 Volt
	[560] = {"560", "Duele...", "Sueltas un anillo de 10 lágrimas al recibir daño#↑ +1.2 de lágrimas al primer golpe#↑ +0.4 a los siguientes golpes#(solo en la habitación actual)"}, --  It Hurts
	[561] = {"561", "Leche de almendras", "↑ +Lágrimas x 4#↓ -Daño x 0.3#Las lágrimas tienen diferentes efectos de trinkets de gusanos"}, --  Almond Milk
	[562] = {"562", "Fondo rocoso", "Previene que tus puntos reduzcan por el resto de la partida"}, --  Rock Bottom
	[563] = {"563", "Nancy Bombas", "+5 bombas#Las bombas explotan con un efecto aleatorio de bombas"}, --  Nancy Bombs
	[564] = {"564", "Una barra de jabón", "↑ +0.5 de lágrimas#↑ +0.2 de velocidad de disparo"}, --  A Bar of Soap
	[565] = {"565", "Cachorro de sangre", "Familiar que persigue a enemigos#Luego de matar muchos enemigos, se hace más fuerte y también te atacará#Al atacarlo regresa a la normalidad"}, --  Blood Puppy
	[566] = {"566", "Atrapasueños", "Medio corazón de alma al ingresar a un nuevo piso#Te muestra los objetos que aparecerán en el siguiente piso durante la transición de pesadillas"}, --  Dream Catcher
	[567] = {"567", "Cirio pascual", "↑ +0.4 de lágrimas por vencer habitaciones sin recibir daño#Funciona hasta 5 veces# Se resetea al recibir daño"}, --  Paschal Candle
	[568] = {"568", "Intervención divina", "Al pulsar 2 veces el botón de disparo crea un escudo#El escudo dura 1 segundo, empuja enemigos y devuelve disparos"}, --  Divine Intervention
	[569] = {"569", "Juramento de sangre", "Te apuñala al inicio de cada piso, quitandote todos los corazones rojos (excepto medio corazón)#Incrementa tus puntos durante el piso:#↑ Daño + 0.15 *corazón perdido^2#↑ Velocidad + 0.05*corazón perdido"}, --  Blood Oath
	[570] = {"570", "Galleta de plastilina", "Te da lágrimas multicolores con diferentes efectos de estado"}, --  Playdough Cookie
	[571] = {"571", "Medias huérfanas", "Previene daño de charcos y picos en el suelo#↑ +0.3 de velocidad#↑ +2 corazones de alma"}, --  Orphan Socks
	[572] = {"572", "Ojo de lo oculto", "Lágrimas controlables#↑ +1 de daño#↑ +7.5 de rango#↓ -0.16 de velocidad de disparo"}, --  Eye of the Occult
	[573] = {"573", "Corazón inmaculado", "+1 Vida#↑ +20% de daño#Salud completa#Posibilidad de disparar lágrimas orbitales"}, --  Immaculate Heart
	[574] = {"574", "Ostensorio", "Recibes un aura que daña a enemigos#El aura interior causa más daño"}, --  Monstrance
	[575] = {"575", "El intruso", "Un familiar en tu cabeza que dispara 4 lágrimas ralentizadoras#Puede salir de tu cabeza al recibir daño"}, --  The Intruder
	[576] = {"576", "Mente sucia", "Al destruir una popó suelta 1-4 enemigos de popó amigables#Varían respecto al tipo de popó"}, --  Dirty Mind
	[577] = {"577", "Damocles", "{{Warning}} DE UN SOLO USO {{Warning}}#Aparece una espada sobre tu cabeza, el cual duplica los objetos en pedestal y recompensas de pordioseros#Te mata en un momento aleatorio al recibir daño"}, --  Damocles
	[578] = {"578", "Limonada gratis", "Crea un gran charco amarillo"}, --  Free Lemonade
	[579] = {"579", "Espada espiritual", "Espada en lugar de lágrimas#Causa 3x tu daño#Da un ataque en giro al recargarlo#Dispara proyectiles con salud completa (o si el numero de corazones es igual o mayor al de vidas)"}, --  Spirit Sword
	[580] = {"580", "Llave roja", "Crea nuevas habitaciones en lugares con contorno de una puerta#Pueden ser habitaciones especiales# Una habitación fuera del mapa del piso (13x13) te llevará a una habitación I AM ERROR"}, --  Red Key
	[581] = {"581", "Mosca psíquica", "Familiar mosca orbital#Persigue y devuelve disparos por un tiempo#Causa daño por contacto"}, --  Psy Fly
	[582] = {"582", "Hongo Mareante", "↑ +0.75 de lágrimas#↓ -0.03 de velocidad#Distorsiona la pantalla#(Durante el piso actual)"}, --  Wavy Cap
	[583] = {"583", "Cohete en un jarro", "+5 bombas#Mientras disparas, las bombas que colocas se vuelven cohetes que se dirigen en la misma dirección del disparo"}, --  Rocket in a Jar
	[584] = {"584", "Libro de virtudes", "Suelta una fuego orbital que dispara lágrimas espectrales pero puede destruirse#Puede combinarse con un segundo objeto activable para diferentes efectos#Convierte la primera habitación diabólica en angelical"}, --  Book of Virtues
	[585] = {"585", "Caja de alabastro", "Suelta 3 corazones de alma y 2 objetos angelicales#Debe recargarse tomando corazones de alma/oscuros#Si se tomo un pacto con el diablo anteriormente, suelta 2 corazones de alma y 1 objeto angelical"}, --  Alabaster Box
	[586] = {"586", "La escalerilla", "Aparece una escalerilla al inicio de cada piso, te lleva a una tienda angelical"}, --  The Stairway
	[587] = {"587", "", "<Item does not exist>"}, -- Menorah (Unused but skripted)
	[588] = {"588", "Sol", "Te muestra la habitación del jefe {{BossRoom}}#Al vencer al jefe, activa XIX - El sol {{Card20}}#También recarga tu objeto activable, +3 de daño, +1 de suerte durante el piso actual"}, --  Sol
	[589] = {"589", "Luna", "Añade una habitación secreta extra {SecretRoom}} y una super secreta{{SuperSecretRoom}} a cada piso#Las habitaciones secretas tienen un haz de luz que aumenta tus lágrimas durante el piso actual"}, --  Luna
	[590] = {"590", "Mercurius", "↑ +0.4 de velocidad#Las puertas siguen abiertas al entrar en una habitación"}, --  Mercurius
	[591] = {"591", "Venus", "+1 Vida#recuperas 1 corazón#Encanta a enemigos cercanos"}, --  Venus
	[592] = {"592", "Terra", "↑ +1.0 de daño#Reemplaza lágrimas por rocas#Daño variable#Destruye obstaculos#Aumenta el retroceso"}, --  Terra
	[593] = {"593", "Mars", "Embiste al pulsar 2 veces el botón de movimiento#Te haces invulnerable y causas tu daño 4x#3 segundos de recarga"}, --  Mars
	[594] = {"594", "Jupiter", "+2 Vidas (vacío)#↑ -0.3 de velocidad#Se recarga al estar quieto#Sueltas gases tóxicos al caminar"}, --  Jupiter
	[595] = {"595", "Saturnus", "Te da un aura circular#Al entrar en una habitación, 7 lágrimas la orbitarán#Posibilidad de atrapar disparos enemigos en la orbita"}, --  Saturnus
	[596] = {"596", "Uranus", "Disparas lágrimas de hielo que ralentizan y congela a enemigos asesinados#Empujas a enemigos congelados y se destruyen en pedazos de hielo"}, --  Uranus
	[597] = {"597", "Neptunus", "Recargas lágrimas mientras no disparas##Al disparar soltarás todas las lágrimas"}, --  Neptunus
	[598] = {"598", "Pluto", "↑ +0.7 de lágrimas#Reduce significativamente el tamaño de Isaac#Los disparos pueden pasar sobre él"}, --  Pluto
	[599] = {"599", "Cabeza vudú", "Aparece una habitación maldita {{CursedRoom}} adicional en cada piso"}, --  Voodoo Head
	[600] = {"600", "Gotas para los ojos", "↑ Aumenta tus lágrimas en el ojo izquierdo un 28%"}, --  Eye Drops
	[601] = {"601", "Acto de contrición", "↑ +Lágrimas#+1 corazón eterno#Permite que aparezcan habitaciones angelicales incluso si tomaste un pacto con el diablo"}, --  Act of Contrition
	[602] = {"602", "Tarjeta de miembro", "Añade una trampilla en cada tienda que te lleva a otra tienda"}, --  Member Card
	[603] = {"603", "Bateria externa", "Suelta 2-4 baterias#Recarga completamente tu objeto activable"}, --  Battery Pack
	[604] = {"604", "Brazalete de mamá", "Te permite agarrar y lanzar rocas, TNT, popó, Hosts y otros obstaculos#Puedes llevarlos por habitaciones"}, --  Mom's Bracelet
	[605] = {"605", "Cuchara heladera", "Suelta un familiar ojo en la habitación actual, el cual deja un rastro rojo#Tus lágrimas del ojo derecho causan 34% más de daño"}, --  The Scooper
	[606] = {"606", "Grieta ocular", "Posibilidad de disparar lágrimas que crean una grieta al tocar el suelo#Atrae a enemigos, pickups y disparos"}, --  Ocular Rift
	[607] = {"607", "Bebé hervido", "Familiar que dispara una explosión de lágrimas en todas direcciones#Causa 3.5 o 5.3 de daño por lágrima"}, --  Boiled Baby
	[608] = {"608", "Bebé congelante", "Familiar con lágrimas petrificantes#Los enemigos congelados están muertos"}, --  Freezer Baby
	[609] = {"609", "D6 Eterno", "Cambia todos los objetos en la habitación#50% de posibilidad de que el objeto desaparezca"}, --  Eternal D6
	[610] = {"610", "Pecho de ave", "Familiar que salta sobre un enemigo al recibir el 1er daño#Causa 45 de daño y suelta una ola de rocas#Luego persigue a los enemigos"}, --  Bird Cage
	[611] = {"611", "Laringe", "Gritas dañando y empujando a enemigos cercanos#El grito se hace más fuerte mientras tienes más carga"}, --  Larynx
	[612] = {"612", "Alma perdida", "Familiar que muere con un golpe, reviviendo al iniciar otro piso#Si sobrevive todo el piso, suelta 2 corazones de alma, 2 corazones eternos u objetos"}, --  Lost Soul
	[613] = {"613", "", "<Item does not exist>"},
	[614] = {"614", "Bombas de sangre", "+1 Vida#Recuperas 5 corazones#Las bombas dejan un charco#Si no tienes bombas, puede soltarlo a cambio de medio corazón"}, --  Blood Bombs
	[615] = {"615", "Mini-Dumpy", "Familiar que flota alrededor#Cuando recibe daño, empuja, confunde o intoxica enemigos cercanos"}, --  Lil Dumpy
	[616] = {"616", "Ojo de pájaro", "Posibilidad de disparar fuego#El daño máximo es 4x tu daño"}, --  Bird's Eye
	[617] = {"617", "Magnetita", "Posibilidad de disparar lágrimas que magnetizan a enemigos#Los cuales atraerán pickups, disparos y otros enemigos"}, --  Lodestone
	[618] = {"618", "Tomate podrido", "Posibilidad de disparar lágrimas que marcan a enemigos#Los enemigos marcados son atacados por otros enemigos"}, --  Rotten Tomato
	[619] = {"619", "Primogenitura", "Diferente efecto en cada personaje"}, --  Birthright
	[620] = {"620", "", "<Item does not exist>"},
	[621] = {"621", "Guisado rojo", "Salud completa#↑ +21.6 de daño#El daño se reduce con el tiempo#↑ +0.02 de daño al matar un enemigo (el efecto desaparece al agotarse el bonus de daño)"}, --  Red Stew
	[622] = {"622", "Génesis", "{{Warning}} DE UN SOLO USO {{Warning}}#Te quita todos tus objetos y pickups#Te teletransporta a un dormitorio con pickups, cofres y trampillas#Por cada objeto perdido te da a elegir entre otros 3 aleatorios"}, --  Genesis
	[623] = {"623", "Llave afilada", "+5 Llaves#Lanza tu llave para causar daño, destruir obstaculos o abrir puertas"}, --  Sharp Key
	[624] = {"624", "Pack Potenciador", "Suelta 5 cartas aleatorias"}, --  Booster Pack
	[625] = {"625", "Mega Hongo", "Te vuelves gigante por 30 segundos#Incrementa el daño y rango#Eres invulnerable, destruyes enemigos y obstaculos#El efecto persiste entre habitaciones"}, --  Mega Mush
	[626] = {"626", "Pieza de Cuchillo 1", "Primera pieza del familiar cichillo"}, --  Knife Piece 1
	[627] = {"627", "Pieza de Cuchillo 2", "Al combinarlo con la Pieza de Cuchillo 1 {{Collectible627}}, crea un familiar cuchillo#Daña a los enemigos#Puede abrir cierta puerta de carne"}, --  Knife Piece 2
	[628] = {"628", "Acta de defunción", "{{Warning}} DE UN SOLO USO {{Warning}}#Te lleva a un piso que contiene todos los objetos del juego#Al tomar un objeto, regresas a la habitación de origen"}, --  Death Certificate
	[629] = {"629", "Mosca Bot", "Orbital que dispara lágrimas con escudo"}, --  Bot Fly
	[630] = {"630", "", "<Item does not exist>"},
	[631] = {"631", "Cuchillo de carnicero", "Divide a los enemigos en 2 pequeñas versiones del mismo con 40% de su salud"}, --  Meat Cleaver
	[632] = {"632", "Nazar", "↑ +2 de suerte#+ medio corazón de alma en cada piso"}, --  Evil Charm
	[633] = {"633", "Dogma", "Otorga vuelo y un solo efecto de Manto sagrado {{Collectible313}} #↑ +2.0 de daño#↑ +0.1 de velocidad#Si tienen menos de 6 corazones, te otorga corazones y corazones de alma"}, --  Dogma
	[634] = {"634", "Purgatorio", "Aparecesn grietas en el suelo en habitaciones con enemigos#Al caminar sobre las grietas invoca a fantasmas explosivos"}, --  Purgatory
	[635] = {"635", "Puntadas", "Suelta un familiar que se mueve en la direcciónde disparo#Al usarlo, intercambia lugares con Isaac y recibes invencibilidad corta#Al teletransportarte sobre algo puede dañarlo o destruirlo"}, --  Stitches
	[636] = {"636", "Tecla R", "{{Warning}} DE UN SOLO USO {{Warning}}#Te teletransporta al pimer piso de una nueva partida#Tus objetos y pickups están intactos"}, --  R Key
	[637] = {"637", "Gotas de Knockout", "Posibilidad de dar puños con gran retroceso y confunde a enemigos"}, --  Knockout Drops
	[638] = {"638", "Borrador", "Lanza un borrador que mata instantaneamente a 1 enemigo#Previene que el enemigo aparezca por el resto de la partida#Puede usarse 1 vez por piso"}, --  Eraser
	[639] = {"639", "Corazón asqueroso", "Te da un corazón podrido al usarlo"}, --  Yuck Heart
	[640] = {"640", "Urna de almas", "Suelta una ola de llamas#Se recarga con cada enemigo muerto"}, --  Urn of Souls
	[641] = {"641", "Aceldama", "Crea una cadena de lágrimas detrás de ti en combate#Las lágrimas causan 3.5 de daño"}, --  Akeldama
	[642] = {"642", "Piel Mágica", "Te da un objeto a cambio de una vida#Lo convierte en un corazón roto#{{Warning}} De un solo uso para El Perdido (the lost)#Mientras más lo uses, más posibilidad que remplace objetos futuros que aparezcan si ya no tienes este objeto"}, --  Magic Skin
	[643] = {"643", "Revelación", "Otorga vuelo y 2 corazones de alma#Dispararás un haz de luz al soltar el botón de disparo en 2.5 segundos"}, --  Revelation
	[644] = {"644", "Premio consuelo", "Incrementa tu punto más bajo#Suelta 3 monedas, 1 bomba, o 1 llave, dependiendo a lo que te falte"}, --  Consolation Prize
	[645] = {"645", "Mini-toma", "Orbital teratoma#Bloquea disparos#Causa daño por contacto#Se divide en pequeñas partes al recibir daño 3 veces#Las versiones pequeñas se rompen en arañas azules#Reaparece 5 segundos después"}, --  Tinytoma
	[646] = {"646", "Bombas de Azufre", "+5 bombas#Las bombas disparan azufre en forma de cruz"}, --  Brimstone Bombs
	[647] = {"647", "4.5 Voltios", "Los objetos activables no se cargan al vencer habitaciones#Se cargan haciendo daño a enemigos#60 de daño = 1 carga"}, --  4.5 Volt
	[648] = {"648", "", "<Item does not exist>"}, -- Pill Crusher
	[649] = {"649", "Ciruela frutal", "Familiar versión pequeña de Baby Plum#Se propulsa diagonalmente, disparando lágrimas hacia atrás"}, --  Fruity Plum
	[650] = {"650", "Flauta ciruela", "Invoca a Baby Plum amigable durante 10 segundos"}, --  Plum Flute
	[651] = {"651", "Estrella de Belén", "Familiar que viaja lentamente hacia la habitación del jefe#Emite un aura que te da +daño y +lágrimas"}, --  Star of Bethlehem
	[652] = {"652", "Bebé en cubo", "Familiar que se desliza al patearlo#Ralentiza y causa daño por contacto, congela enemigos muertos"}, --  Cube Baby
	[653] = {"653", "Vade Retro", "Mientras lo tienes, los enemigos muertos aparecen como fantasmas rojos#Al activarlo, los fantasmas explotan"}, --  Vade Retro
	[654] = {"654", "PHD falso", "Identifica todas las pildoras#+1 corazón oscuro#Convierte píldoras buenas en malas#↑ Píldoras con efecto negativo aumentan tu daño#Otras píldoras sueltan corazones oscuros"}, --  False PHD
	[655] = {"655", "Gira para Ganar", "Obtienes un orbital que bloquea disparos y daña a enemigos#Al activarlo,↑ +0.5 de velocidad e incrementa la velocidad de tus orbitales"}, --  Spin to Win
	[656] = {"656", "", "<Item not obtainable>"}, -- Damocles
	[657] = {"657", "Vasculitis", "Los enemigos explotan en lágrimas al morir, el cual daña a otros enemigos"}, --  Vasculitis
	[658] = {"658", "Célula Gigante", "Suelta mini-Isaacs al recibir daño#Persiguen y disparan a enemigos"}, --  Giant Cell
	[659] = {"659", "Tropicamida", "↑ +1.5 de rango#Incrementa el tamaño de las lágrimas"}, --  Tropicamide
	[660] = {"660", "Cartomancia", "Aparecen 2 portales al inicio de cada piso#Desaparecen al dejar la habitación#{{ColorRed}}Rojo: {{CR}}Habitación del jefe#{{ColorYellow}}Amarillo: {{CR}}Habitación de objeto#{{ColorBlue}}Azul: {{CR}}Habitación secreta"}, --  Card Reading
	[661] = {"661", "Quinteto", "Suelta un familiar con disparos en el lugar que muere un enemigo#Hasta 5 familiares"}, --  Quints
	[662] = {"662", "", "<Item does not exist>"}, -- Pacifist (Cut item)
	[663] = {"663", "Diente y Uña", "Te vuelves invencible por 1 segundo cada 6 segundos, causando daño por contacto"}, --  Tooth and Nail
	[664] = {"664", "Comedor compulsivo", "+1 Vida#Los objetos en pedestal cambian seguidamente por el predefinido y un alimento +Vida#Al tomar el alimento obtienes +3.6 de daño (reduce con el tiempo)"}, --  Binge Eater
	[665] = {"665", "Ojo de Guppy", "Muestra el contenido de los cofres, bolsas, y fogatas"}, --  Guppy's Eye
	[666] = {"666", "", "<Item does not exist>"},
	[667] = {"667", "Hombre de trapo", "Aparece Keeper como segundo personaje#Si muere, suelta arañas azules#Luego desaparece por completo"}, --  Strawman
	[668] = {"668", "Nota de Papá", "Empiezas el camino hacia casa"}, --  Dad's Note
	[669] = {"669", "Salchicha", "+ Vida#Recuperas toda tu salud#↑ +0.5 de daño#↑ +0.2 de velocidad# +0.5 de lágrimas#↑ +0.2 de velocidad de disparo#↑ +1.5 de rango#↑ +1 de suerte"}, --  Sausage
	[670] = {"670", "¿Opciones??", "Aparecen 2 premios al vencer una habitación#Al tomar uno, el otro desaparece"}, --  Options?
	[671] = {"671", "Dulce de Corazón", "Aumenta uno de tus puntos aleatoriamente al tomar corazones rojos"}, --  Candy Heart
	[672] = {"672", "Una libra de carne", "Los tratos con el diablo se pagan con monedas#Los objetos en la tienda cuestan vidas#Lo demás en la tienda es gratis pero está rodeado por picos"}, --  A Pound of Flesh
	[673] = {"673", "Redención", "Te da 1 corazón de alma y +1.0 de daño al entrar a una habitación diabólica y no tomar objetos"}, --  Redemption
	[674] = {"674", "Grilletes espirituales", "Al morir, el alma de Isaac está encadenado a su cuerpo y continúa luchando con medio corazón#Regresas a la vida después de 10 segundos#Se recarga con 1 corazón de alma"}, --  Spirit Shackles
	[675] = {"675", "Orbe Roto", "Al recibir daño, revela una habitación en el mapa#También abre una puerta que necesite llave#Puede revelar habitaciones super secretas"}, --  Cracked Orb
	[676] = {"676", "Corazón vacío", "Te da +vida (vacío) al iniciar un nuevo piso, si bajas con un corazón vacío#No cuentan los corazones de hueso"}, --  Empty Heart
	[677] = {"677", "Proyección Astral", "Al recibir daño, detienes el tiempo por 3 segundos#Isaac se convierte en fantasma y abandona su cuerpo"}, --  Astral Projection
	[678] = {"678", "Cesárea", "Disparas fetos espectrales#Tienen disparos dirigidos"}, --  C Section
	[679] = {"679", "Mini-Abaddón", "Familiar que lanza anillos oscuros"}, --  Lil Abaddon
	[680] = {"680", "Venganza de Moctezuma", "Al disparar, recargas un ataqué en réfaga#Lo disparas por atrás"}, --  Montezuma's Revenge
	[681] = {"681", "Mini-Portal", "Avanza por la habitación causando daño por contacto#Consume pickups por su camino#Cada uno incrementará su tamaño, daño y soltará moscas azules#Por cada 4 pickups, soltará un portal hacia una habitación inexplorada"}, --  Lil Portal
	[682] = {"682", "Gusano amigo", "Saldrá un tentaculo del suelo#Puede agarrar a un enemigo y causarle daño"}, --  Worm Friend
	[683] = {"683", "Espuelas de hueso", "Los enemigos sueltan huesos flotantes al morir#Los huesos bloquean disparos y causan daño por contacto"}, --  Bone Spurs
	[684] = {"684", "Alma hambrienta", "Posibilidad de soltar un fantasma al matar un enemigo#El fantasma persigue a enemigos y explota luego de 5 segundos"}, --  Hungry Soul
	[685] = {"685", "Jarro de Fuegos Fatuos", "Suelta fuegos orbitales que disparan lágrimas, bloquean disparos y causan daño por contacto#El numero de fuegos incrementa con los usos"}, --  Jar of Wisps
	[686] = {"686", "Medallón de alma", "Aumenta uno de tus puntos al tomar corazones de alma#Suelta 1 corazón de alma"}, --  Soul Locket
	[687] = {"687", "Buscador de amigos", "Suelta un monstruo amigable que copia los movimientos y ataques de Isaac"}, --  Friend Finder
	[688] = {"688", "Niño interior", "+1 Vida extra#Revivies en la misma habitación con medio corazón, tamaño diminuto y +0.2 de velocidad"}, --  Inner Child
	[689] = {"689", "Corona con Falla", "Los objetos en pedestal cambian seguidamente entre 5 aleatorios"}, --  Glitched Crown
	[690] = {"690", "Belly Jelly", "Los enemigos rebotan al tocar a Isaac#Los enemigos reciben daño si chocan con algo al rebotar#Posibilidad de bloquear disparos"}, --  Belly Jelly
	[691] = {"691", "Orbe Sagrado", "Incrementa la calidad de los objetos que aparezcan#Reduce la aparición de objetos malos"}, --  Sacred Orb
	[692] = {"692", "Vínculo de Sangre", "Aparecen unos picos en la habitación diabólica#Al causarte daño en ellos te otorga un premio:#35% de 6 monedas#15% +0.5 de daño#5% de 2 corazones oscuros#2% de objeto aleatorio#1% transformación en Leviathan"}, --  Sanguine Bond
	[693] = {"693", "El enjambre", "Te da 9 moscas orbitales que se vuelven moscas azules cuando reciben daño#Suelta una nueva mosca al vencer una habitación"}, --  The Swarm
	[694] = {"694", "Corazón roto", "Te da 3 corazones rotos#↑ +0.25 de daño por cada corazón roto#Mueres al tener 12 corazones rotos"}, --  Heartbreak
	[695] = {"695", "Ventarrón sangriento", "Al recibir daño obtienes + velocidad y lágrimas por el resto del piso"}, --  Bloody Gust
	[696] = {"696", "Salvación", "Otorga un halo que invoca rayos de luz al tocar enemigos#El halo se hace más grande con cada daño que recibes (durante el piso actual)"}, --  Salvation
	[697] = {"697", "Gemelo desvaneciente", "Familiar que se vuelve en una copia del jefe en la habitación#Al vencerlo, suelta un objeto extra#El clon es más lento y tiene 75% de la salud del jefe"}, --  Vanishing Twin
	[698] = {"698", "Dúo retorcido", "2 familiares demonios que se ponen a tu lado#Copian tus lágrimas pero solo con un 37.5% de tu daño"}, --  Twisted Pair
	[699] = {"699", "Furia de Azazel", "Incrementa tu ira al vencer habitaciones#Luego de 4 habitaciones, dispara un gran rayo de azufre al entrar a la siguiente habitación"}, --  Azazel's Rage
	[700] = {"700", "Cámara de ecos", "Al usar una carta, píldora o runa activa una copia de las 3 últimas cartas, píldoras o runas que usaste después de tomar este objeto"}, --  Echo Chamber
	[701] = {"701", "Tumba de Isaac", "Suelta un cofre viajo al iniciar cada piso#Puede contener corazones de alma, trinkets o objetos angelicales, de mamá o papá"}, --  Isaac's Tomb
	[702] = {"702", "Espíritu vengativo", "Al recibir daño, suelta un fuego orbital durante el piso#Un máximo de 6#Disparan lágrimas pero no bloquean#Causan daño por contacto"}, --  Vengeful Spirit
	[703] = {"703", "Esaú Jr.", "Cambias entre tu personaje y Esau Jr., el cual tiene 3 corazones oscuros, +2 de daño y vuelo#Los personajes tienen objetos y salud independiente#{{Warning}} Al morir uno de los 2 termina la partida"}, --  Esau Jr.
	[704] = {"704", "¡Berserk!", "Modo Berserk por unos segundos:#↑ +0.4 de velocidad#↑ + lágrimas#↑ +3.0 de daño#Solo puedes usar un hueso como arma"}, --  Berserk!
	[705] = {"705", "Artes oscuras", "Al usarlo, obtienes ↑ +1.0 de velocidad y la habilidad de caminar sobre enemigos/disparos por 1 segundo#Incrementa el daño por cada enemigo tocado#Daña a los enemigos tocados 3x tu daño"}, --  Dark Arts
	[706] = {"706", "Abismo", "Suelta una mosca de ataque por cada objeto en pedestal que es destruido#El efecto de la mosca depende del objeto"}, --  Abyss
	[707] = {"707", "Banquete", "+1 Vida#Recuperas 1 corazón"}, --  Supper
	[708] = {"708", "Engrapadora", "↑ +1.0 de daño#Solo disparas lágrimas por un ojo"}, --  Stapler
	[709] = {"709", "¡Suplex!", "Te permite embestir a enemigos y golpearlos contra el suelo#Puedes controlar la dirección del golpe#El golpe causa 50 de daño y crea una ola de rocas"}, --  Suplex!
	[710] = {"710", "Bolsa de crafteo", "Puedes recolectar hasta 8 pickups#Al mantener preisonado el botón del activable, creas un objeto#La calidad del objeto depende de la calidad de los pickups"}, --  Bag of Crafting
	[711] = {"711", "Cambio", "Cambias personajes entre Lázaro y Lázaro muerto"}, --  Flip
	[712] = {"712", "Lemegeton", "Suelta objetos orbitales fantasmas#El efecto del objeto es aplicado a Isaac#El objeto es seleccionado de acuerdo a la habitación"}, --  Lemegeton
	[713] = {"713", "Sumptorium", "Al presionar el botón de disparo convertirá medio corazón en un familiar coágulo#Al activarlo convierte a los familiares de nuevo en corazones#El tipo de corazón cambia el comportamiento del familiar"}, --  Sumptorium
	[714] = {"714", "Llamado", "Regresa la cabeza del Olvidado (the forgotten) a su dueño"}, --  Recall
	[715] = {"715", "Frasco", "Guarda una bombba de popó para usarlo después"}, --  Hold
	[716] = {"716", "Bolsa de Keeper", "Incrementa tu daño, velocidad o rango al comprar cosas en la tienda#Suelta 3 monedas y una llave"}, --  Keeper's Sack
	[717] = {"717", "Parientes de Keeper", "Las rocas y vasijas sueltan 2 arañas azules al ser destruidas"}, --  Keeper's Kin
	[718] = {"718", "", "<Item does not exist>"}, -- Keepers Robe (Cut item)
	[719] = {"719", "Caja de Keeper", "Suelta un objeto/pickup aleatorio de tienda"}, --  Keeper's Box
	[720] = {"720", "Jarra para todo", "Suelta pickups de acuerdo a la carga que tiene#Al estar completamente cargado, tiene un gran efesto aleatorio#Premios por carga: 1:popó 2:{{Coin}} 3:{{Bomb}} 4:{{Key}} 5:{{Heart}} 6:{{Pill}} 7:{{Card}} 8:{{SoulHeart}} 9:{{GoldenHeart}} 10:{{GoldenKey}} 11:{{GoldenBomb}}"}, --  Everything Jar
	[721] = {"721", "TMTRAINER", "Causa que tus objetos futuros tengan fallas#Les da efectos totalmnte aleatorios"}, --  TMTRAINER
	[722] = {"722", "Anima Sola", "Encadena a un enemigo cercano por 5 segundos, evitando que se mueva"}, --  Anima Sola
	[723] = {"723", "Dado reductor", "Cambia cada objeto en la habitación restando 1 numero a su codigo ID interno"}, --  Spindown Dice
	[724] = {"724", "Hipercoagulación", "Al recibir daño, sueltas medio o 1 corazón#Los corazones desaparecen en 2 segundos"}, --  Hypercoagulation
	[725] = {"725", "IBS", "Al causar daño, tienes la posibilidad de activar el efecto:#Lanzar una popó#Un charco#Un pedo#Soltar 5 bombas troll"}, --  IBS
	[726] = {"726", "Hemoptisis", "Pulsa 2 veces el botón de disparo para estornudar sangre#Causa 150% de daño a enemigos en frente de Isaac#Se recarga en 1 segundo"}, --  Hemoptysis
	[727] = {"727", "Bombas fantasmas", "+5 bombas#Las bombas sueltan un fantasma que causa daño por contacto y explota luego de 10 segundos"}, --  Ghost Bombs
	[728] = {"728", "Gello", "Suelta un familiar demonio que está unido a Isaac#Copia las lágrimas y efectos de Isaac"}, --  Gello
	[729] = {"729", "Ataque decapitado", "Lanza la cabeza de Isaac y disparas desde el lugar en el que aterriza#Lo recuperas al buscarlo o reactivarlo"}, --  Decap Attack
	[730] = {"730", "Ojo de vidrio", "↑ +0.75 de daño#↑ +1 de suerte"}, --  Glass Eye
	[731] = {"731", "Orzuelo", "!!! Solo se aplica al ojo derecho#↑ +28% de daño#↑ +7 de rango#↓ -0.3 velocidad de disparo"}, --  Stye
	[732] = {"732", "Anillo de mamá", "↑ +1 de daño#Suelta un runa o piedra de alma aleatoria al tomarlo"}, --  Mom's Ring
}
EID:updateDescriptionsViaTable(repCollectibles, EID.descriptions[languageCode].collectibles)

EID.descriptions[languageCode].birthright ={
	{"Isaac", "", "Los objetos cambian entre dos objetos"},
	{"Magdalene", "Magdalena", "↑ {{Heart}} +1 corazón, límite de corazones aumentado a 18"},
	{"Cain", "Caín", "↑ {{Luck}} Suerte +1#{{ArcadeRoom}} Todos los pisos tienen Arcades garantizados menos Cofre y Cuarto oscuro#{{ArcadeRoom}} Mejores arcades"},
	{"Judas", "", "{{Collectible34}} El Libro de Belial actúa como un objeto pasivo, similar a {{Collectible584}} El Libro de las Virtudes, el aumento de daño escala con la carga de los objetos activos#Varios objetos activos reciben interacciones especiales"},
	{"???", "", "{{ArrowUp}} {{SoulHeart}} Los corazones de alma recibidos de aumentos de vida se duplican"},
	{"Eve", "Eva", "Whore of Babylon se activa sin depender de la vida#Dead Bird se activa sin recibir daño"},
	{"Samson", "Sansón", "Bloody Lust puede ganar 4 mejoras de daño hasta un máximo de +14,0"},
	{"Azazel", "", "El ataque de Azazel es más ancho, como el de Mega Blast#No varía el daño"},
	{"Lazarus", "Lázaro", "Al morir, revive como Lázaro resucitado#{{Damage}} Lázaro resucitado gana una mejora de daño de +21,6 que se pierde poco a poco"},
	{"Eden", "Edén", "Genera 3 objetos aleatorios de pools de objetos aleatorias#Solo se puede coger uno"},
	{"The Lost", "El Perdido", "Evita la aparición de objetos inútiles para El Perdido#Ejemplos: Aumentos de vida, vuelo, lágrimas espectrales o los que requieren daño para activarse"},
	{"Lazarus Risen", "Lázaro Resucitado", "Otorga una mejora de daño de +21,6 que se pierde poco a poco"},
	{"Black Judas", "Judas Oscuro", "{{Collectible34}} El Libro de Belial actúa como un objeto pasivo, similar a {{Collectible584}} El Libro de las Virtudes, el aumento de daño escala con la carga de los objetos activos"},
	{"Lilith", "", "Los familiares se colocan frente a Lilith, mejor control de ataque"},
	{"Keeper", "", "↑ {{Coin}} +1 moneda de salud, el límite de salud llega a 4"},
	{"Apollyon", "Apolión", "Posibilidad de generar un objeto destruído anteriormente#Mientras más objetos consumidos, más posibilidad de generarlo#No afecta a objetos activos"},
	{"The Forgotten", "El Olvidado", "El alma no está atado y se mueve libremente"},
	{"The Forgotten Soul", "El Alma", "El alma no está atado y se mueve libremente"},
	{"Bethany", "", "Activar un objeto usando cargas de alma a veces es gratis"},
	{"Jacob", "", "El personaje que recoge un objeto obtiene copias de tres objetos pasivos del otro personaje"},
	{"Esau", "Esaú", "El personaje que recoge un objeto obtiene copias de tres objetos pasivos del otro personaje"},
	{"Tainted Isaac", "Isaac contaminado", "Añade 4 espacios adicionales para objetos pasivos"},
	{"Tainted Magdalene", "Magdalena contaminada", "{{Heart}} Añade 1 al límite de corazones"},
	{"Tainted Cain", "Caín contaminado", "La cantidad de recolectables que se generan al coger un objeto se duplica"}, -- Y hasta acá se queda esto
	{"Tainted Judas", "Judas contaminado", "Usar {{Collectible705}} Artes Oscuras otorga un aura con área de ataque mayor"},
	{"Tainted ???", "??? contaminado", "Aumenta el número máximo de cacas que puedes llevar a 29"},
	{"Tainted Eve", "Eva contaminada", "Los coágulos generados de corazones rojos sueltan medio corazón rojo que desaparece al morir"},
	{"Tainted Samson", "Sansón contaminado", "El contador del modo berserker gana 3 segundos en lugar de 1 cuando Sansón contaminado mata a un enemigo"},
	{"Tainted Azazel", "Azazel contaminado", "El tamaño de Hemoptisis {{Collectible726}}, el ataque de Azazel contaminado es el doble de grande"},
	{"Tainted Lazarus", "Lázaro contaminado", "El Lázaro que no se esté usando estará presente como un fantasma, siendo controlado como J&E#No puede recibir daño ni interactuar con el entorno#La versión fantasma hace su daño al 25%"},
	{"Tainted Eden", "Edén contaminado", "Los objetos pasivos y actuvis conseguidos antes de Primogenitura no cambian al recibir daño"},
	{"Tainted Lost", "El Perdido contaminado", "Otorga una vida extra que revive a Tainted Lost (Lost contaminado) en la misma habitación y causa 200 de daño a los enemigos cercanos#Puede golpear al mismo enemigo varias veces"},
	{"Tainted Lilith", "Lilith contaminada", "Los familiares son lanzados junto a Gello"},
	{"Tainted Keeper", "Keeper contaminado", "Atrae las monedas que sueltan los enemigos cercanos al morir#No afecta al resto de monedas"},
	{"Tainted Apollyon", "Apolión contaminado", "Las langostas se quedan atacando a un enemigo mientras se siga disparando"},
	{"Tainted Forgotten", "Forgotten contaminado", "El alma contaminada gana la habilidad {{Collectible714}} Llamado, puedes recuperar automáticamente a Forgotten contaminado desde la distancia"},
	{"Tainted Bethany", "Bethany contaminada", "Genera 4 grandes fuegos fatuos#Tienen mayor durabilidad que los regulares"},
	{"Tainted Jacob", "Jacob contaminado", "Otro Dark Esau aparecerá#Al usar {{Collectible722}} Anima Sola, ambos serán encadenados, ambos pueden ser soltados uno a uno"},
	{"Dead Tainted Lazarus", "Lázaro contaminado muerto", "El Lázaro que no se esté usando estará presente como un fantasma, siendo controlado como J&E#No puede recibir daño ni interactuar con el entorno#La versión fantasma hace su daño al 25%"},
	{"Tainted Jacob 2", "Jacob contaminado (fantasma)", "Otro Dark Esau aparecerá#Al usar {{Collectible722}} Anima Sola, ambos serán encadenados, ambos pueden ser soltados uno a uno"},
	{"Tainted Forgotten Soul", "El alma contaminada", "El alma contaminada gana la habilidad {{Collectible714}} Llamado, puedes recuperar automáticamente a Forgotten contaminado desde la distancia"},
}

-- Buffs caused by Binge Eater
-- Note: "#" will be replaced with "#{{Collectible664}} " automatically, in order to add Binge eater icon infront of each buff-bulletpoint

EID.descriptions[languageCode].bingeEaterBuffs = {
	[22] = "↑ {{Tears}} Lágrimas +0.5#↑ {{Range}} Alcance +1.5#↓ {{Speed}} Velocidad -0.03", -- Lunch
	[23] = "↑ {{Tears}} Lágrimas +0.5#↑ {{Shotspeed}} Vel. de tiro +0.2#↓ {{Speed}} Velocidad -0.03", -- Dinner
	[24] = "↑ {{Damage}} Daño +1#↑ +0.2 de velocidad de lágrima#↓ {{Speed}} Velocidad -0.03", -- Dessert
	[25] = "↑ {{Shotspeed}} Vel. de tiro +0.2#↑ {{Range}} Alcance +1.5#↓ {{Speed}} Velocidad -0.03", -- Breakfast
	[26] = "↑ {{Damage}} Daño +1#↑ {{Range}} Alcance +1.5#↓ {{Speed}} Velocidad -0.03", -- Rotten Meat
	[456] = "↑ {{Damage}} Daño +1#↑ {{Luck}} Suerte +1#↓ {{Speed}} Velocidad -0.03", -- Midnight Snack
	[346] = "↑ {{Shotspeed}} Vel. de tiro +0.2#↑ {{Luck}} Suerte +1#↓ {{Speed}} Velocidad -0.03", -- A Snack
	[707] = "↑ {{Tears}} Lágrimas +0.5#↑{{Luck}} Suerte +1#↓ {{Speed}} Velocidad -0.03", -- Supper
}

-- Buffs caused by Book of Belial with Judas' Birthright
-- Note: "#" will be replaced with "#{{Collectible34}} " automatically, in order to add Book of Belial icon infront of each buff-bulletpoint

EID.descriptions[languageCode].bookOfBelialBuffs = {
	[40] = "También activa el efecto de {{Collectible35}} El Necronomicón", -- Kamikaze!
	[126] = "También activa el efecto de {{Collectible35}} El Necronomicón", -- Razor Blade
	[127] = "Aumento de daño durante todo el nuevo piso", -- Forget me Now
	[133] = "Aumento de daño permanente", -- Guppy's Paw
	[135] = "Aumento de daño por cada uso", -- IV Bag
	[147] = "El pico tiene mayor velocidad, empuje, duración, prende a los enemigos en fuego y suelta más recolectables al romper cacas y obstáculos", -- Notched Axe
	[186] = "También activa el efecto de {{Collectible126}} Cuchilla", -- Blood Rights
	[282] = "Deja un rastro de fuego que quema a los enemigos", -- How to Jump
	[290] = "Gasta un corazón a la vez, Otorga un aumento de daño y deja creep rojo en el suelo", -- The Jar
	[295] = "Probabilidad de activar el efecto de {{Collectible555}} Cuchilla dorada", -- Magic Fingers
	[297] = "Genera un familiar demoniaco junto a la recompensa basada en el piso", -- Pandora's Box
	[323] = "Las lágrimas lanzadas tienen un aumento de daño", -- Isaac's Tears
	[352] = "Activa el Libro de Belial al romperse - el daño persiste hasta que el cañón es reparado", -- Glass Cannon
	[475] = "Reapareces como Dark Judas si tienes una vida extra", -- Plan C
	[482] = "Reemplaza el objeto adquirido más reciente por {{Collectible51}} Pentáculo", -- Clicker
	[487] = "Incrementa el aumento de daño", -- Potato Peeler
	[536] = "{{Damage}} Daño temporal +10.8 por cada familiar sacrificado, disminuye con el tiempo igual que {{Collectible621}} Asado rojo", -- Sacrificial Altar
	[555] = "Daña a todos los enemigos de la sala y aplica el efecto de {{Collectible202}} Toque de Midas en ellos", -- Golden Razor
	[563] = "Los fantasmas irán a los enemigos", -- Vade Retro
	[577] = "Aumento de daño permanente", -- Damocles
	[582] = "Aumento de daño adicional por el resto del piso basado en la cantidad de veces que se usó", -- Wavy Cap
	[585] = "Cambia las recompensas por 2 corazones negros y un objeto de trato con el Diablo#Serán 3 corazones negros y 2 objetos si ya se hizo un trato con el diablo", -- Alabaster Box
	[622] = "Otorga gratuitamente un {{Collectible51}} Pentáculo", -- Genesis
	[623] = "También activa el efecto de {{Collectible126}} Cuchilla", -- Sharp Key
	[635] = "Crea una línea de {{Collectible705}} Artes Oscuras entre tú y Pespuntes", -- Stitches
	[640] = "Lanza un rayo de {{Collectible118}} Azufre", -- Urn of Souls
	[642] = "Aumento de daño permanente", -- Magic Skin
	[685] = "Otorga 6 fuegos fatuos de {{Collectible292}} Biblia satánica que aumentan la posibilidad de sala del Diablo", -- Jar of Wisps
	[705] = "Permite tener un aumento temporal de daño", -- Dark Arts
	[710] = "Tomar corazones rojos da la posibilidad de cambiarlos por corazones negros", -- Bag of Crafting
	[729] = "Gran aumento de daño y lágrimas cuando la cabeza es lanzada", -- Decap Attack
}

-- Book of Virtues wisp types
EID.descriptions[languageCode].bookOfVirtuesWisps = {
	[33] = "Disparos teledirigidos", -- The Bible
	[34] = "Disparos con daño x2", -- The Book of Belial
	[35] = "3.5% de poribilidad de lanzar lágrimas horrorizadoras#Se activa el efecto del Necronomicón al destruirse", -- The Necronomicon
	[36] = "2.5% de posibilidad de disparos de {{Collectible236}} E. Coli", -- The Poop
	[37] = "Generan bombas de dispersión al destruirse", -- Mr. Boom 
	[38] = "Disparos rápidos e imprecisos", -- Tammy's Head
	[39] = "5% de posibilidad de disparos petrificadores", -- Mom's Bra
	[40] = "Disparos explosivos#Explotan al destruirse", -- Kamikaze!
	[41] = "7.5% de posibilidad de disparos horrorizadores", -- Mom's Pad
	[42] = "7.5% de posibilidad de disparos de {{Collectible149}} Ipecac", -- Bob's Rotten Head
	[44] = "10% de posibilidad de disparos que teletransportan enemigos#Los fuegos parpadean cada 5 segundos", -- Teleport!
	[45] = "20% de posibilidad de que un enemigo suelte un corazón al morir", -- Yum Heart
	[47] = "Disparos con daño al 1/2#Todos los fuegos generados por el objeto lanzarán 3 disparos explosivos hacia donde apunte la cruz tras usarse", -- Doctor's Remote
	[49] = "No puede disparar normalmente#Lanzará un disparo de Kamehame... ¡¿Eeeeeeh?! al usarlo", -- Shoop da Whoop!
	[56] = "Disparos rápidos de corto rango#Los fuegos dejarán caer creep amarillo", -- Lemon Mishap
	[58] = "Inmunidad a proyectiles", -- Book of Shadows
	[65] = "Genera una bomba troll al destruírse", -- Anarchist Cookbook
	[66] = "Ralentiza a los enemigos por 3 segundos al destruirse", -- The Hourglass
	[77] = "Daño de contacto extra", -- My Little Unicorn
	[78] = "No puede disparar#Genera un Familiar de {{Collectible562}} 7 Sellos al destruirse#Duran una habitación", -- Book of Revelations
	[83] = "Disparos con empuje", -- The Nail
	[84] = "Sin efecto especial", -- We Need to Go Deeper!
	[85] = "Genera una carta al destruirse", -- Deck of Cards
	[86] = "Disparos dentales", -- Monstro's Tooth
	[93] = "Disparos anti-gravitatorios#Capacidad de lanzar disparos horrorizadoras", -- The Gamekid
	[97] = "Genera 1 de 8 fuegos: {{Collectible65}}{{Collectible42}}{{Collectible85}}{{Collectible102}}{{Collectible37}}{{Collectible177}}{{Collectible49}}{{Collectible45}}#Los efectos explosivos son comunes", -- The Book of Sin
	[102] = "Genera 1 de 6 fuegos de distinto color con distintos efectos#Posibilidad de envenenar, petrificar, confundir, , lanzar disparos de Bombas Troll, O generar una araña enemiga al destruírse#Los 6 fuegos generan píldoras al destruirse", -- Mom's Bottle of Pills
	[105] = "Genera un fuego extra por cada objeto reroleado", -- The D6
	[107] = "Disparos pentrantes", -- The Pinking Shears
	[111] = "Pedo venenoso al destruirse", -- The Bean
	[123] = "Disparos aleatorios", -- Monster Manual
	[124] = "Genera un fuego de lo que sea que imitó", -- Dead Sea Scrolls
	[126] = "Fuego de alto PV", -- Razor Blade
	[127] = "Fuego de PC infinito por todo el nuevo piso", -- Forget Me Now
	[130] = "No puede disparar#Los fuegos cargarán hacia donde dispares", -- A Pony
	[133] = "3 fuegos de alto PV", -- Guppy's Paw
	[135] = "Sin efecto especial", -- IV Bag
	[136] = "7.5% de posibilidad lanzar disparos marcadores#Los enemigos marcados atacarán a otros enemigos", -- Best Friend
	[137] = "1 fuego por bomba detonada#Los disparos también pueden ser detonados a distancia", -- Remote Detonator
	[145] = "Se generan fuegos en vez de moscas#Generan una mosca azul al destruirse", -- Guppy's Head
	[146] = "Disparos teledirigidos", -- Prayer Card
	[147] = "Romper rocas puede generar 1 de 5 fuegos de varios materiales#posibilidad de efectos de carbón, confusión, monedas, daño doble o disparos láser", -- Notched Axe
	[158] = "Disparos apuntados#Genera fuegos de alto PV", -- Crystal Ball
	[160] = "Generan rayos de luz al contacto", -- Crack the Sky
	[164] = "Fuego de una sola habitación", -- The Candle
	[166] = "Destruye todos los recolectables#Posibilidad de generar un fuego por cada recolectable destruido", -- D20
	[171] = "7.5% de posibilidad de lanzar disparos realentizadores", -- Spider Butt
	[175] = "Los fuegos abren cofres/puertas al contacto#Puede abrir las puertas a Mega Satán, Cadaver y al Ascenso", -- Dad's Key
	[177] = "Genera un fuego basado en la recompensa ganada", -- Portable Slot
	[181] = "10% de lanzar disparos de {{Collectible374}} Luz Sagrada", -- White Pony
	[186] = "Fuego de alto PV", -- Blood Rights
	[192] = "Disparos teledirigidos", -- Telepathy for Dummies
	[263] = "15% de posibilidad de que los enemigos suelten una runa al morir#Generan una runa al destruirse", -- Clear Rune
	[282] = "Hasta 6 fuegos inmóviles", -- How to Jump
	[283] = "Rerolea todos tus fuegos, añadiendo uno aleatorio#No cambia el Libro de las Virtudes", -- D100
	[284] = "Elimina todos los fuegos#Otorga un fuego aleatorio por cada 2 objetos conseguidos#No cambia el Libro de las Virtudes", -- D4
	[285] = "10% de posibilidad de activar el efecto del D10 al golpear", -- D10
	[286] = "15% de posibilidad de que un enemigo suelte una carta al morir#Generan una carta al destruirse", -- Blank Card
	[287] = "Se activa el efecto del {{Collectible675}} Orbe roto al destruise", -- Book of Secrets
	[288] = "Se generan fuegos en vez de arañás#Generan una araña azul al destruirse", -- Box of Spiders
	[289] = "Fuegos de una sola habitación#Lágrimas de flamas rojkas", -- Red Candle
	[290] = "Crea un fuego por corazón#Posibilidad de generar {{HalfHeart}} medio corazón al destruirse", -- The Jar
	[291] = "Genera un fuego extra por cada enemigo transformado en caca", -- Flush!
	[292] = "+10% de posibilidad de {{DevilRoom}}sala del Diablo o {{AngelRoom}} sala del Ángel por cada fuego de la Biblia Satánica", -- Satanic Bible
	[293] = "Dispara un láser en 4 direcciones al destruirse", -- Head of Krampus
	[294] = "Fuego de una sola habitación#No puede disparar#El efecto del Frijol Mantequilla se activa al destruirse", -- Butter Bean
	[295] = "Posibilidad de soltar una moneda al destruirse", -- Magic Fingers
	[296] = "Sin efecto especial", -- Converter
	[297] = "Sin efecto especial", -- Pandora's Box
	[298] = "No pueden disparar#Inmunidad al daño por contacto#No harán daño de contacto hasta que el Paso de unicornio se active", -- Unicorn Stump, Hasta acá lo voy a dejar por el momento, cuando me despierte y limpie continuaré
	[323] = "Genera 3 fuegos#Tiempo de vida de 3 segundos", -- Isaac's Tears
	[324] = "Disparos de la {{Collectible570}} Galleta de plastilina", -- Undefined
	[325] = "Conjunto de disparos arqueados", -- Scissors
	[326] = "Genera un fuego al recibir daño", -- Breath of Life
	[338] = "Fuego de una sola habitación#Disparos de búmeran", -- The Boomerang
	[347] = "Disparos de 20/20#Duplica tus otros fuegos", -- Diplopia
	[348] = "Genera una píldora al destruirse", -- Placebo
	[349] = "50% de generar una moneda al destruirse", -- Wooden Nickel
	[351] = "Todos los fuegos del Mega Frijol lanzan una onda de piedra al usar el objeto#Pedo venenoso y petrificador al destruirse", -- Mega Bean
	[352] = "Si un fuego del Cañón de cristal se destruye, los otros lo harán#Persisten entre habitaciones", -- Glass Cannon
	[357] = "Duplica tus fuegos durante la habitación", -- Box of Friends
	[382] = "Los enemigos pueden generar un fuego con disparo regular, teledirigido, explosivo, o de {{Collectible118}} Azufre al morir, dependiendo de su set de movimientos", -- Friendly Ball
	[383] = "Los disparos de los fuegos pueden ser detonados, transformándose en 6 lágrimas del jugador#Lanza lágrimas del jugador al destruirse#Persisten entre habitaciones", -- Tear Detonator
	[386] = "5% de posibilidad de que los disparos cambien los objetos del ambiente al golpearlos (exceptuando popó y TNT)", -- D12
	[396] = "No pueden disparar#Cada pasadizo tendrá un fuego", -- Ventricle Razor
	[406] = "Daño y cadencia de tiro aleatorias", -- D8
	[419] = "20% de posibilidad de que las lágrimas teletransporten enemigos#Los fuegos parpedean cada 5 segundos", -- Teleport 2.0
	[421] = "Genera un pedo encantador al destruirse", -- Kidney Bean
	[422] = "30% de posibilidad de lanzar disparos petrificadores", -- Glowing Hour Glass
	[427] = "Genera un fuego que rebota por la habitación, Explotarán al hacer contacto con una lágrima del jugador#No puede disparar o hacer daño por contacto", -- Mine Crafter
	[434] = "Se generan fuegos en vez de moscas#De 5 moscas en adelante se generará un fuego con salud y daño incrementado 1", -- Jar of Flies
	[437] = "Efecto del D7 al hacer daño por contacto#Sólo se activa una vez", -- D7
	[439] = "Sin efecto especial", -- Mom's Box
	[441] = "Lágrimas del {{Collectible275}} Mini-Azufre (Disparo cargado)#Dispararán de forma continua mientras se use Mega Ráfaga", -- Mega Blast
	[475] = "8 fuegos de daño elevado", -- Plan C
	[476] = "Genera un fuego si no se duplica un recolectable", -- D1
	[477] = "Genera los fuegos de todos los objetos activos absorvidos#No genera fuegos por sí solo", -- Void
	[478] = "Pausa a todos los enemigos y permite disparar por 3 segundos", -- Pause
	[479] = "Posibilidad de generar un trinket al destruirse", -- Smelter
	[480] = "La salud del fuego aumentará dependiendo de los recolectables reciclados", -- Compost
	[481] = "5% de posibilidad de lanzar disparos que transformen a los enemigos en fuegos aleatorios", -- Dataminer
	[482] = "Genera un fuego aleatorio", -- Clicker
	[483] = "8 fuegos que generan una bomba troll al destruirse", -- Mama Mega!
	[484] = "Fuego de una sola habitación#No puede disparar#Se activa el efecto de Espera... ¿qué? al destruirse", -- Wait What?
	[485] = "Los fuegos de la Moneda Doblada pueden ser duplicados o totalmente destruidos si uno se daña", -- Crooked Penny
	[486] = "No puede disparar#Posibilidad de negar el daño recibido", -- Dull Razor
	[487] = "Fuego permanente#Acecha y dispara a los enemigos#No bloquea disparos ni hace daño por contacto", -- Potato Peeler
	[488] = "Genera un fuego de lo que sea que imitó (Fuego aleatorio si no fue un objeto activo)", -- Metronome
	[489] = "Genera un fuego normal en adición a fuego del dado imitado", -- D Infinity
	[490] = "Genera un fuego aleatorio#Resurge en la siguiente habitación si fue destruido", -- Eden's Soul
	[504] = "Fuego de una sola habitación#Disparos rápidos y apuntados", -- Brown Nugget
	[507] = "Posibilidad de generar fuegos al matar", -- Sharp Straw
	[510] = "Disparos del {{Collectible229}} Pulmón de Monstro, {{Collectible268}} Bebé Podrido, {{Collectible87}} Cuernos de Loki o {{Collectible118}} Azufre", -- Delirious
	[512] = "Disparos magnéticos", -- Black Hole
	[515] = "Genera un fuego aleatorio#", -- Mystery Gift
	[516] = "Disparos en 8 direcciones imitando al Aspersor", -- Sprinkler
	[521] = "Disparo triple#All Coupon tears are destroyed if you make a purchase", -- Coupon
	[522] = "Captured projectiles turn into wisps", -- Telekinesis
	[523] = "Los fuegos se generan al soltar el contenido de la caja#Generan un recolectable al destruirse", -- Moving Box
	[527] = "No pueden disparar#Pueden abrir cofres y puertas en las habitaciones vacías", -- Mr. ME!
	[536] = "Convierte todos los fuegos en {{HalfHeart}} Medios corazones#Genera un fuego bastante fuerte al sacrificar", -- Sacrificial Altar
	[545] = "Los fuegos generan un Bony amistoso al destruirse", -- Book of the Dead
	[550] = "10% de posibilidad de lanzar un disparo que genere un pisotón sobre el enemigo", -- Broken Shovel
	[552] = "10% de posibilidad de lanzar un disparo que genere un pisotón sobre el enemigo#Genera un fuego de alto PV que no dispara", -- Mom's Shovel
	[555] = "15% de lanzar un disparo con el efecto del {{Collectible202}} Toque de midas", -- Golden Razor
	[556] = "Disparos láser de corto alcance", -- Sulfur
	[557] = "{{ArrowUp}} +0.2 de suerte por cada fuego de la Galleta de la fortuna", -- Fortune Cookie
	[577] = "Sin efecto especial", -- Damocles
	[578] = "Los fuegos dejan caer creep amarillo", -- Free Lemonade
	[580] = "Posibilidad de generar puertas rojas al entrar a una nueva habitación", -- Red Key
	[582] = "Hasta 1 fuego del Hongo Mareante", -- Wavy Cap
	[584] = "Sin beneficio por copias múltiples", -- Book of Virtues
	[585] = "Genera 8 fuegos", -- Alabaster Box
	[604] = "Fuego de una habitación#Se generan 3 fuegos cuando algo que lanzaste aterriza#10% de posibilidad de lanzar disparos que confunden", -- Mom's Bracelet
	[605] = "Sin efecto especial", -- The Scooper
	[609] = "Fuego invisible#50% de posibilidad de que todos los fuegos del D6 Eterno se destruyan al usarse", -- Eternal D6
	[611] = "Daño y salud aumentados en base a las cargas tras utilizarlo", -- Larynx
	[622] = "3 fuegos#Remueve todos los otros fuegos ", -- Genesis
	[623] = "Sin efecto especial", -- Sharp Key
	[631] = "Parte tus fuegos a la mitad (Mitad de salud y daño)#Los fuegos se destruyen si se parten 3 veces", -- Meat Cleaver
	[635] = "Deja un fuego estacionario#Hasta 6 fuegos estacionarios", -- Stitches
	[636] = "No hay fuego", -- R Key
	[638] = "Elimina enemigos no-jefes al contacto", -- Eraser
	[639] = "No puede disparar#Genera una mosca azul al limpiar una sala", -- Yuck Heart
	[640] = "Posibilidad de lanzar una flama azul", -- Urn of Souls
	[642] = "Disparos venenosos", -- Magic Skin
	[650] = "Cuando Ciruelita dispare de forma diagonal, Todos los fuegos de la Flauta Ciruela lo harán", -- Plum Flute
	[653] = "No hay fuegos#Los fantasmas rojos pueden disparar lágrimas", -- Vade Retro
	[655] = "Fuegos temporales al usarse", -- Spin to Win
	[685] = "Duplica todos los fuegos generados, añade uno extra", -- Jar of Wisps
	[687] = "Genera un fuego aleatorio", -- Friend Finder
	[703] = "Sin efecto especial", -- Esau Jr.
	[704] = "Fuego de alto PV#No puede disparar", -- Berserk
	[705] = "Fuego de una habitación generado por enemigo asesinado", -- Dark Arts
	[706] = "Fuego de alto PV#No puede disparar", -- Abyss
	[709] = "Fuego de una habitación#Se generan 3 fuegos en donde aterrices", -- Suplex
	[710] = "Genera un fuego aleatorio al momento de fabricar", -- Bag of Crafting
	[711] = "Sin efecto especial", -- Flip
	[712] = "Los fuegos de objetos lanzan disparos teledirigidos", -- Lemegeton
	[713] = "No hay fuego", -- Sumptorium
	[719] = "20% de posibilidad de que un enemigo suelte un fuego al morir", -- Keeper's Box
	[720] = "Genera un fuego aleatorio", -- Everything Jar
	[722] = "Orbita alrededor del enemigo encadenado mientras le dispara#El fuego morirá cuando el enemigo lo haga", -- Anima Sola
	[723] = "Rerolea todos los fuegos, convirtiéndolos a uno del mismo tipo", -- Spindown Dice
	[728] = "Todos los fuegos orbitarán a Gello", -- Gello
	[729] = "Fuego estacionario", -- Decap Attack
	
}

-- Special Locust effects when Item was eaten by Abyss
EID.descriptions[languageCode].abyssSynergies = {
	[2] = "3 langostas regulares", -- The Inner Eye
	[3] = "Langostas purpuras teledirigidas", -- Spoon Bender
	[4] = "Langosta grande que inflinge el triple de tu daño", -- Cricket's Head
	[6] = "Langosta amarilla de corto rango, provoca daño con mayor velocidad", -- Number One
	[7] = "Langosta roja que inflinge el doble de tu daño", -- Blood of the Martyr
	[10] = "2 langostas grices que infligen la mitad de tu daño", -- Halo of Flies
	[13] = "Langosta verde que envenena enemigos", -- The Virus
	[103] = "Langosta verde que envenena enemigos", -- The Common Cold
	[118] = "Langosta gris más grande, es más que nada normal", -- Brimstone
	[149] = "Langosta grande, lenta y verde, inflinge tu daño x1.5 y envenena enemigos", -- Ipecac
	[153] = "4 langostas regulares", -- Mutant Spider
	[257] = "Langosta ardiente naranja, prende a los enemigos en fuego", -- Fire Mind
	[305] = "Langosta verde que envenena anemigos", -- Scorpio
	[374] = "Langosta brillante de color Cyan, puede generar un rayo de luz que inflinge tu daño x3", -- Holy Light
	[494] = "Langosta azul claro con arcos de electricidad, inflingen 0.1 de daño por toque", -- Jacob's Ladder
	[559] = "Langosta azul claro con arcos de electricidad, inflingen 0.1 de daño por toque", -- 120 Volt
}

EID.descriptions[languageCode].spindownError = "El objeto desaparece"

---------- Trinkets ----------

local repTrinkets={
	[1] = {"1", "Moneda tragada", "Generas monedas cuando te golpean"},
	[10] = {"10", "Gusano ondulante", "Las lágrimas se mueven en ondas#↑ {{Tears}} Lágrimas +0.4#Otorga lágrimas espectrales"}, -- Gusano ondulante
	[11] = {"11", "Gusano anillo", "Las lágrimas se mueven en espirales a gran velocidad#↑ {{Tears}} Lágrimas +0.4#Otorga lágrimas espectrales"}, -- Gusano anillo
	[26] = {"26", "Gusano de gancho", "Las lágrimas se mueven en ángulos#↑ {{Tears}} Lágrimas +0.4#↑ {{Range}} Alcance +1.5#Otorga lágrimas espectrales"}, -- Gusano de gancho
	[33] = {"33", "Cordón umbilical", "Al tener medio corazón, aparece un pequeño Steven#Gran posibilidad de que aparezca un familiar Géminis al recibir daño"}, -- Cordón umbilical
	[49] = {"49", "Moneda sangrienta", "25 % de posibilidad de dejar caer medio corazón al coger monedas"}, -- Moneda sangrienta
	[50] = {"50", "Moneda quemada", "25 % de posibilidad de dejar una bomba al coger monedas"}, -- Moneda quemada
	[51] = {"51", "Moneda plana", "25 % de posibilidad de dejar una llave al coger monedas"}, -- Moneda plana
	[69] = {"69", "Polaroid descolorida", "Te camufla de manera aleatoria#Desorienta a los enemigos#Puede usarse para abrir la puerta hacia la planta \"Home\" (Casa)"}, -- Polaroid descolorida
	[92] = {"92", "Corona rota", "↑ Las estadísticas basadas en tus objetos son un 20 % más efectivas"}, -- Corona rota
	[96] = {"96", "Serpiente Uróboros", "Las lágrimas se mueven rápido en espiral#Lágrimas espectrales#↑ +1.5 de rango"}, -- Ouroboros Worm
	[111] = {"111", "Corona sangrienta", "Las salas del tesoro {{TreasureRoom}} aparecen en el Womb (Útero) y Corpse (Cadáver)"}, -- Corona sangrienta
	[119] = {"119", "Célula madre", "Reduce tus corazones rojos al 50 % de tu máximo al entrar en la siguiente planta#Si tu vida está por encima, cura medio corazón rojo"}, -- Célula madre
	[128] = {"128", "Dedo de hueso", "5 % de posibilidad de ganar un corazón de hueso al recibir daño"}, -- Dedo de hueso
	[129] = {"129", "Rompemandíbulas", "Probabilidad de disparar lágrimas diente"}, --  Rompemandíbulas
	[130] = {"130", "Boli mordido", "Probabilidad de disparar lágrimas ralentizantes"}, --  Boli mordido
	[131] = {"131", "Moneda bendita", "Probabilidad de dejar caer medio corazón de alma al coger monedas"}, --  Moneda bendita
	[132] = {"132", "Jeringuilla rota", "Probabilidad de ganar un efecto de jeringuilla aleatoria en la habitación actual"}, --  Jeringuilla rota
	[133] = {"133", "Fusible corto", "Las bombas colocadas explotan más rápido"}, --  Fusible corto
	[134] = {"134", "Judía gigante", "Aumenta el tamañó de los pedos"}, --  Judía gigante
	[135] = {"135", "Mechero", "Probabilidad de quemar a los enemigos el entrar en la habitación"}, --  Mechero
	[136] = {"136", "Candado roto", "Las puertas, candados y cofres dorados pueden abrirse con explosiones#También puede abrir la puerta de Casa"}, --  Candado roto
	[137] = {"137", "Miosotis", "Al bajar a una nueva planta, se generan hasta cuatro recolectables no obtenidos de la planta anterior"}, --  Miosotis
	[138] = {"138", "'M", "Usar un objeto activo lo cambia"}, --  'M
	[139] = {"139", "Amuleto de lágrima", "Los efectos de lágrima basados en la suerte ocurren más a menudo"}, --  Amuleto de lágrima
	[140] = {"140", "Manzana de Sodoma", "Coger corazones rojos puede convertirlos en arañas azules#Funciona incluso si tienes vida al completo#Puede tragarse corazones que necesitas para curarte"}, --  Manzana de Sodoma
	[141] = {"141", "Nana olvidada", "Aumenta la velocidad de disparo de los familiares"}, --  Nana olvidada
	[142] = {"142", "La fe de Beth", "Al inicio de cada planta, genera 4 fuegos del Book of Virtues (Libro de las virtudes) {{Collectible584}}"}, --  La fe de Beth
	[143] = {"143", "Condensador antiguo", "Evita que el objeto activo se cargue#Posibilidad de generar una paqueña batería al limpiar la habitación"}, --  Condensador antiguo
	[144] = {"144", "Gusano del cerebro", "Las lágrimas giran en ángulos de 90 grados para golpear a los enemigos si no iban a acertar"}, --  Gusano del cerebro
	[145] = {"145", "Perfección", "↑ +10 de suerte#Se destruye si recibes daño"}, --  Perfeccción
	[146] = {"146", "Corona del diablo", "Las habitaciones doradas {{TreasureRoom}} contienen ahora pactos del diablo"}, --  Corona del diablo
	[147] = {"147", "Moneda cargada", "Coger monedas puede cargar el objeto activable"}, --  Moneda cargada
	[148] = {"148", "Collar de la amistad", "Hace que los familiares giren a tu alrededor"}, --  Collar de la amistad
	[149] = {"149", "Botón del pánico", "Puede activar tu objeto activable al recibir daño"}, --  Botón del pánico
	[150] = {"150", "Llave azul", "Entrar en una habitación que requiere una llave te lleva a una habitación similar a la de Hush#Actúa como un medio entre dos habitaciones"}, --  Llave azul
	[151] = {"151", "Lima plana", "Hace que los pinchos se retraigan, por lo que no hacen daño#También afecta a las puertas de las habitaciones malditas {{CursedRoom}}, y cualquier obstáculo con pinchos"}, --  Lima plana
	[152] = {"152", "Lente de telescopio", "{Posibilita que aparezca un segundo Planetario#Los planetarios ahora podrán aparecer en el Womb (Útero)"}, --  Lente de telescopio
	[153] = {"153", "Pelo de Mamá", "En cada habitación otorga un efecto aleatorio de un objeto de Mamá"}, --  Pelo de Mamá
	[154] = {"154", "Bolsa de dados", "Al entrar en una habitación, otorga un consumible temporal de dado#El dado desaparece al cambiar de habitación#Ahora puedes llevar dos consumibles"}, --  Bolsa de dados
	[155] = {"155", "Corona sagrada", "Genera una habitación de dorada {{TreasureRoom}} en la Catedral"}, --  Corona sagrada
	[156] = {"156", "Beso de Mamá", "Otorga un contenedor de vida roja#También funciona con Keeper"}, --  Beso de Mamá
	[157] = {"157", "Carta rasgada", "Cada 15 disparos, suela una lágrima de Ipecac {{Collectible149}} + una lágrima de My Reflection {{Collectible5}} con mucho rango"}, --  Carta rasgada
	[158] = {"158", "Bolsillo roto", "Cuando te golpean, se te caen todos los recolectables#(Excepción: Corazones, cartas, píldoras, runas)"}, --  Bolsillo roto
	[159] = {"159", "Llave de oro", "Reemplaza todos los cofres sin abrir por cofres cerrados#Excepción: mega cofres"}, --  Llave de oro
	[160] = {"160", "Saco de la suerte", "Genera un saco al bajar de planta"}, --  Saco de la suerte
	[161] = {"161", "Corona malvada", "Genera una habitación dorada {{TreasureRoom}} en Sheol"}, --  Corona malvada
	[162] = {"162", "Cuerno roto de Azazel", "Posibilidad de convertirse en Azazel al entrar a una nueva habitación"}, --  Cuerno roto de Azazel
	[163] = {"163", "Dingle Berry", "Genera dos caquitas amistosas al limpiar una habitación"}, --  Dingle Berry
	[164] = {"164", "Anilla de protección", "Genera dos bombas adicionales por cada bomba que pongas"}, --  Anilla de protección
	[165] = {"165", "Ah, no", "En Womb (Útero) y más allá, cambia todos los recolectables que se generan por un recolectable aleatorio#Las bombas y los corazones son más comunes"}, --  Ah, no
	[166] = {"166", "Arcilla de modelar", "Otorga el efecto de un Objeto pasivo aleatorio en cada habitación"}, --  Arcilla de modelar
	[167] = {"167", "Hueso pulido", "Posibilidad de generar un hueso amistoso al limpiar la habitación"}, --  Hueso pulido
	[168] = {"168", "Corazón vacío", "+1 corazón de hueso al bajar a un nuevo piso"}, --  Corazón vacío
	[169] = {"169", "Dibujo infantil", "Al tenerlo, cuenta como un objeto para la transformación en Guppy"}, --  Dibujo infantil
	[170] = {"170", "Llave de cristal", "Otorga la posibilidad de crear automáticamente salas de Red Key {{Collectible580}} al limpiar una habitación"}, --  Llave de cristal
	[171] = {"171", "La ganga de Keeper", "Los pactos del diablo usan monedas en lugar de corazones"}, --  La ganga de Keeper
	[172] = {"172", "Moneda maldita", "Teletransporta a una habitación aleatoria al recoger una moneda#Puede teletransportarte a habitaciones secretas"}, --  Moneda maldita
	[173] = {"173", "Tu alma", "{{Warning}} UN SOLO USO {{Warning}}#Puede usarse para pagar pactos del diablo sin perder corazones"}, --  Tu alma
	[174] = {"174", "Imán de número", "+10 % de posibilidad de pacto del diablo"}, --  Imán de número
	[175] = {"175", "Llave extraña", "Desbloquea el pasaje a Blue Womb y la lucha de Hush, independientemente del tiempo#Usar la Pandora's Box {{Collectible297}} genera 6 objetas de pools aleatorias"}, --  Llave extraña
	[176] = {"176", "Mini coágulo", "Genera un familiar coágulo que copia tu movimiento, la dirección del disparo y los efectos de lágrima"}, --  Mini coágulo
	[177] = {"177", "Tatuaje temporal", "Genera un cofre después de limpiar una sala de desafíos, o un objeto después de limpiar una sala de desafíos de jefe"}, --  Tatuaje temporal
	[178] = {"178", "M80 mojado", "Isaac explota al recibir daño"}, --  M80 mojado
	[179] = {"179", "Mando a distancia", "En lugar de ir detrás, los familiares se mueven como tú"}, --  Mando a distancia
	[180] = {"180", "Alma encontrada", "Familiar que sigue los movimientos exactos y dispara lágrimas espectrales#Tiene el mismo daño y efectos que tú"}, --  Alma encontrada
	[181] = {"181", "Pack de expansión", "El uso de un elemento activo desencadena otro efecto de elemento activo aleatorio"}, --  Pack de expansión
	[182] = {"182", "Esencia de Beth", "Una vez por piso,  recibir daño generará un fuego fatuo {{Collectible584}} y otorgará unos segundos de invulnerabilidad#Genera 5 fuegos al entrar en una habitación de ángel#Crea un fuego al dar dinero a los vagabundos"}, --  Esencia de Beth
	[183] = {"183", "Los gemelos", "Cada habitación:#Sin familiares: Posibilidad de hacer aparecer un Brother Bobby {{Collectible8}} o una Sister Maggy {{Collectible67}}# Con familiares: posibilidad de añadir o duplicar un familiar"}, --  Los gemelos
	[184] = {"184", "Papeles de adopción", "Las tiendas pueden vender familiares#Los familiares siempre tienen descuento"}, --  Papeles de adopción
	[185] = {"185", "Pata de grillo", "Agrega la posibilidad de generar una langosta aleatoria al matar a un enemigo"}, --  Pata de grillo
	[186] = {"186", "El mejor amigo de Apollyon", "{{Throwable}} {{ColorOrange}}Throwable{{CR}} (usar dos veces el botón de disparo)#Garantiza 2 moscas familiares con las que disparar"}, --  El mejor amigo de Apollyon
	[187] = {"187", "Gafas rotas", "33 % de probabilidad de añadir un objeto adicional a ciegas en la habitación del tesoro#Revela el objeto a ciegas in la ruta alternativa"}, --  Gafas rotas
	[188] = {"188", "Cubo de hielo", "Posibilidad de petrificar a un enemigo al entrar en la habitación#Matar al enemigo petrificado lo congela"}, --  Cubo de hielo
	[189] = {"189", "Sello de Baphomet", "Activa un escudo de un segundo al matar a un enemigo"}, --  Sello de Baphomet
}
EID:updateDescriptionsViaTable(repTrinkets, EID.descriptions[languageCode].trinkets)

EID.descriptions[languageCode].goldenTrinket = "DORADO: ¡Efecto duplicado!"

---------- Cards ----------

local repCards={
	[4] = {"4", "III - La Emperatriz", "Durante la habitación, recibes: #↑ {{Damage}} Daño +2.35#↑ {{Speed}} Velocidad +0.3"},
	[12] = {"12", "XI - Fuerza", "Durante la habitación actual, recibes: #↑ {{Heart}} +1 de vida#↑ {{Speed}} Velocidad +0.3#↑ {{Damage}} Daño +50% y +0.3#↑{{Range}} Alcance +1.5"},
	[16] = {"16", "XV - El Diablo", "↑ {{Damage}} Daño +2 durante la habitación actual"},
	[18] = {"18", "XVII - Las Estrellas", "{{TreasureRoom}} Te teletransporta a la sala del tesoro#{{Planetarium}} Te llevará al planetario si es que hay dicho"},
	[27] = {"27", "", "Convierte todos los recolectables, cofres y enemigos no jefes en bombas"},
	[28] = {"28", "", "Convierte todos los recolectables, cofres y enemigos no jefes en monedas"},
	[29] = {"29", "", "Convierte todos los recolectables, cofres y enemigos no jefes en llaves"},
	[30] = {"30", "", "Convierte todos los recolectables, cofres y enemigos no jefes en corazones"},
	[39] = {"39", "", "Invencibilidad durante 20 segundos"},
	[51] = {"51", "Carta sagrada", "{{HolyMantle}} Otorga el efecto de Manto Sagrado (Holy Mantle) la planta actual"},
	[55] = {"55", "Fragmento de runa", "{{Rune}} Activa un efecto de runa aleatoria#El efecto es débil"},
	[52] = {"52", "Gran Crecimiento", "Durante la habitación actual, recibes: #↑ {{Damage}} Daño +7#↑ {{Range}} Alcance +30#↑ +Tamaño#Capacidad de romper rocas"},
	[54] = {"54", "Caminando una Era", "Durante la habitación actual, recibes: #↑ {{Speed}} Velocidad +0.5#{{Shotspeed}} Vel. de tiro -0.40#Los enemigos se ralentizan"},
	[56] = {"56", "0 - ¿El Bufón?", "Deja caer los corazones y recolectables al suelo#Te deja con medio corazón#Los recolectables pueden generarse como los recolectables {{Collectible74}} {{Collectible19}} si hay una cantidad suficiente"},
	[57] = {"57", "I - ¿El Mago?", "Otorga un aura protectora contra los proyectiles grandes y los enemigos#Dura un minuto"},
	[58] = {"58", "II - ¿La Gran Sacerdotisa?", "El pie de mamá pisa repetidamente durante 1 minuto"},
	[59] = {"59", "III - ¿La Emperatriz?", "Efecto temporal:#↑ {{Heart}} +2 corazones rojos#↑ {{Tears}} Lágrimas +1.35"},
	[60] = {"60", "IV - ¿El Emperador?", "Te teletransporta a una sala del jefe adicional con más recompensa"},
	[61] = {"61", "V - ¿El Sumo Sacerdote?", "{{EmptyBoneHeart}} Genera 2 corazones de hueso"},
	[62] = {"62", "VI - ¿Los Enamorados?", "Genera un objeto de la pool de la sala actual#{{BrokenHeart}} Convierte 1 corazón rojo o 2 corazones de alma en un corazón roto"},
	[63] = {"63", "VII - ¿El Carruaje?", "Te convierte en una estatua invencible durante 10 segundos#Gran velocidad de disparo mientras dure"},
	[64] = {"64", "VIII - ¿Justicia?", "Genera de 2 a 4 cofres dorados"},
	[65] = {"65", "IX - ¿El Ermitaño?", "Convierte los recolectables y objetos de la habitación en monedas#El valor de las monedas es el mismo que su precio en la tienda"},
	[66] = {"66", "X - ¿La Rueda de la Fortuna?", "Efecto aleatorio de la sala de dados"},
	[67] = {"67", "XI - ¿Fuerza?", "Los enemigos de la habitación se vuelven más débiles, lentos y reciben el doble de daño"},
	[68] = {"68", "XII - ¿El Colgado?", "Te conviertes en Keeper durante 30 segundos#Otorga disparo triple y menos velocidad#Los enemigos asesinados dejan caer monedas"},
	[69] = {"69", "XIII - ¿Muerte?", "Otorga el efecto de Book of the Dead {{Collectible545}} (Libro de los muertos)#(Genera entidades de hueso por cada enemigo eliminado en la habitación)"},
	[70] = {"70", "XIV - ¿Templanza?", "Aplica 5 efectos de píldora aleatorios"},
	[71] = {"71", "XV - ¿El Diablo?", "Otorga el efecto de {{Collectible33}} La Biblia#Genera un familiar Serafín {{Collectible390}}# Dura 30 segundos"},
	[72] = {"72", "XVI - ¿La Torre?", "Genera 6 grupos de rocas y obstáculos aleatorios"},
	[73] = {"73", "XVII - ¿Las Estrellas?", "Elimina el objeto pasivo más antiguo#Genera 2 objetos aleatorios de la pool de la sala actual"},
	[74] = {"74", "XVIII - ¿La Luna?", "Te teletransporta a la sala ultrasecreta#El camino de vuelta será de habitaciones rojas"},
	[75] = {"75", "XIX - ¿El Sol?", "Ganas el objeto Spirit of the Night {{Collectible159}} (Espíritu de la noche)#↑ +1,5 de daño# Dura en la planta actual#Convierte los corazones rojos en corazones de hueso, pero los devuelve al acabar el efecto#Aplica Curse of Darkness (Maldición de oscuridad)"},
	[76] = {"76", "XX - ¿El Juicio?", "Genera una máquina de restock"},
	[77] = {"77", "XXI - ¿El Mundo?", "Genera una trampilla"},
	[78] = {"78", "Llave Rota", "{{Collectible580}} Llave Roja de' un solo uso"},
	[79] = {"79", "Reina de Corazones", "{{Heart}} Genera de 1 a 20 corazones rojos"},
	[80] = {"80", "Comodín", "Copia el efecto del último recolectable activado: píldora, carta, runa, piedra de alma u objeto activo"},
	[81] = {"81", "Alma de Isaac", "Cambia los objetos de la habitación#Lo alterna con la forma original tras un segundo#El efecto se repite"},
	[82] = {"82", "Alma de Magdalena", "Te rodea con un aura roja burbujeante en la habitación actual#Los enemigos asesinados dejan caer medios corazones rojos que desaparecen en 2 segundos"},
	[83] = {"83", "Alma de Caín", "{{Collectible580}} Crea habitaciones rojas para cada posible salida"},
	[84] = {"84", "Alma de Judas", "Te convierte en un fantasma que puede atravesar enemigos y paralizarlos#Tras unos segundos, les ataca a todos"},
	[85] = {"85", "Alma de ???", "Suelta 8 pedos venenosos con creep marrón#Después deja un rastro de 7 Butt Bombs (Bombas culo)#Quedarse en el creep otorga ↑ +1,35 de lágrimas y ↑ +1 de daño"},
	[86] = {"86", "Alma de Eva", "14 familiares Dead Bird (Pájaro muerto) atacan a los enemigos# Dura en la habitación actual"},
	[87] = {"87", "Alma de Sansón", "Te convierte en Sansón berserker con ataque a melé durante 10 segundos#↑ +0,4 de velocidad#↑ Más lágrimas#↑ +3 de daño"},
	[88] = {"88", "Alma de Azazel", "{{Collectible441}} Activa Mega Blast durante 7,5 segundos"},
	[89] = {"89", "Alma de Lázaro", "Mueres y revives inmediatamente con medio corazón y un rato de invencibilidad#El objeto se usa automáticamente al recibir un daño fatal (como una vida adicional)"},
	[90] = {"90", "Alma de Edén", "Activa el efecto de D6 {{Collectible105}} y el de D20 {{Collectible166}}#El objeto cambiado usa pools de objetos aleatorias"},
	[91] = {"91", "Alma del perdido", "Te convierte en The Lost en la habitación actual"},
	[92] = {"92", "Alma de Lilith", "Añade un familiar aleatorio"},
	[93] = {"93", "Alma de Keeper", "{{Coin}} Genera de 3 a 25 monedas aleatorias"},
	[94] = {"94", "Alma de Apolión", "Genera 15 langostas aleatorias"},
	[95] = {"95", "Alma del olvidado", "Aparece The Forgotten como un segundo personaje en la habitación actual"},
	[96] = {"96", "Alma de Bethany", "Genera 6 fuegos fatuos de Book of Virtues {{Collectible584}} (Libro de las virtudes) con propiedades aleatorias"},
	[97] = {"97", "Alma de Jacob y Esaú", "Aparece Esaú como un segundo personaje en la habitación actual"},
}
EID:updateDescriptionsViaTable(repCards, EID.descriptions[languageCode].cards)


---------- Tarot Cloth Buffs ----------
EID.descriptions[languageCode].tarotClothBuffs = {
	[2] = "También otorga el efecto de {{Collectible34}} El libro de Belial", -- I - The Magician
	[3] = "Un segundo pie atacará en cuanto el primero lo haga", -- II - The High Priestess
	[4] = "Duplica el aumento de estadísticas", -- III - The Empress
	[5] = "Si el jefe no ha sido derrotado, Recibes un {{SoulHeart}} Corazón de alma", -- IV - The Emperor
	[6] = "Genera 3 corazones de alma", -- V - The Hierophant
	[7] = "Genera 3 corazones rojos", -- VI - The Lovers
	[8] = "Duración duplicada", -- VII - The Chariot
	[9] = "Duplica la generación de recolectables", -- VIII - Justice
	[10] ="Evita que Codicia aparezca en las tiendas#Si ya se peleó contra Codicia, la tienda regresará a la normalidad", -- IX - The Hermit
	[11] = "Genera 2 máquinas tragaperras", -- X - Wheel of Fortune
	[12] = "Duplica el aumento de estadísticas, excepto el multiplicador de daño", -- XI - Strength
	[14] = "Inflinge 80 de daño", -- XIII - Death
	[15] = "Genera 2 Máquinas de donación de sangre", -- XIV - Temperance
	[16] = "Aumento de daño duplicado", -- XV - The Devil
	[17] = "Genera 12 bombas troll", -- XVI - The Tower
	[18] = "Si no se ha entrado a la sala del tesoro, esta tendrá 2 posibles opciones", -- XVII - The Stars
	[21] = "Genera 2 mendigos", -- XX - Judgement
	[56] = "Sueltas tanto los recolectables como los objetos, Incluyendo el Tapete de tarot", -- 0 - The Fool?
	[59] = "↑ Salud +3", -- III - The Empress?
	[61] = "Genera 3 corazones de hueso", -- V - The Hierophant?
	[62] = "Añade 2 corazones rotos y genera 2 objetos", -- VI - The Lovers?
	[64] = "Genera 4-14 cofres dorados", -- VIII - Justice?
	[70] = "Consumes 10 píldoras", -- XIV - Temperance?
	[72] = "Generas 14 agrupaciones de rocas", -- XVI - The Tower?
	[73] = "Retira 2 objetos y genera otros 4", -- XVII - The Stars?
	[76] = "Generan 4 máquinas de reabastecimiento", -- XX - Judgement?
}

---------- Pills ----------

local repPills={
	[4] = {"3", "Las bombas son la «clave»", "Intercambia el número de bombas por el de llaves#Las llaves y bombas de oro también se intercambian"},
	[12] = {"11", "- Alcance", "↓ {{Range}} Alcance -0.6"},
	[13] = {"12", "+ Alcance", "↑{{Range}} Alcance +0.75"},
	[14] = {"13", "Menos velocidad", "↓ {{Speed}} Velocidad -0.12"},
	[15] = {"14", "Más velocidad", "↑ {{Speed}} Velocidad +0.15"},
	[16] = {"15", "Menos lágrimas", "↓ {{Tears}} Lágrimas -0.28"},
	[17] = {"16", "Más lágrimas", "↑ {{Tears}} Lágrimas +0.35"},
	[18] = {"17", "Menos suerte", "↓ {{Luck}} Suerte -1"},
	[19] = {"18", "Más suerte", "↑ {{Luck}} Suerte +1"},
	[42] = {"41", "Tengo sueño...", "Te ralentiza a ti y a los enemigos de la habitación"},
	[43] = {"42", "¡¡TENGO MUCHA ENERGÍA!!", "Aumenta tu velocidad y la de todos los enemigos de la habitación#Se vuelve a activas tras 30 y 60 segundos"},
	[48] = {"47", "- Velocidad de lágrimas", "↓ {{Shotspeed}} Vel. de tiro -0.15"},
	[49] = {"48", "+ Velocidad de lágrimas", "↑ {{Shotspeed}} Vel. de tiro +0.15"},
	[50] = {"49", "Píldora experimental", "↑ Aumenta una estadística aleatoria#↓ Disminuye otra estadística aleatoria#Si tienes PHD no bajará ninguna"},
	[9999] = {"", "Píldora dorada", "Efecto de píldora aleatorio#Se destruye tras unos cuantos usos"}, -- golden Pill
}
EID:updateDescriptionsViaTable(repPills, EID.descriptions[languageCode].pills)

EID.descriptions[languageCode].horsepills={
	{"0", "", "Envenena toda la habitación"},
	{"1", "", "Te inflige 2 corazones de daño"},
	{"2", "", "{{SoulHeart}} +4 corazones de alma"},
	{"3", "", "Intercambia el número de bombas y de llaves#Aumenta el número de llaves y de bombas en un 50 %#Las bombas y llaves doradas también se intercambian"},
	{"4", "", "Genera enormes bombas troll teledirigidas en tu posición"},
	{"5", "", "Vida al completo#{{SoulHeart}} +3 corazones de alma"},
	{"6", "", "↓ {{Heart}} -2 corazones"},
	{"7", "", "↑ {{EmptyHeart}} +2 contenedores de vida vacíos"},
	{"8", "", "Sin efecto"},
	{"9", "", "Sin efecto"}, -- Puberty
	{"10", "", "Añade 1 mosca orbital Big Fan {{Collectible279}} (Gran fan)#No hay límite máximo"},
	{"11", "", "↓ {{Range}} Alcance -1.2"},
	{"12", "", "↑ {{Range}} Alcance +0.9"},
	{"13", "", "↓ {{Speed}} Velocidad -0.24"},
	{"14", "", "↑ {{Speed}} Velocidad +0.3"},
	{"15", "", "↓ {{Tears}} Lágrimas -0.56"},
	{"16", "", "↑ {{Tears}} Lágrimas +0.70"},
	{"17", "", "↓ {{Luck}} Suerte -2"},
	{"18", "", "↑ {{Luck}} Suerte +2"},
	{"19", "", "Te teletransporta a una habitación aleatoria"}, -- TODO
	{"20", "", "Recarga el objeto activo#Deja caer baterías"}, -- TODO
	{"21", "", "Drena todos los contenedores de corazón menos uno#Genera corazones rojos"}, -- TODO
	{"22", "", "No te puedes mover durante 4 segundos"},
	{"23", "", "Abre las entradas de las habitaciones secretas de la planta actual#Muestra el mapa completo"},
	{"24", "", "Convierte a cada enemigo de la habitación actual en amigo"},
	{"25", "", "Oculta el mapa de esta planta"}, --TODO
	{"26", "", "Genera un charco que cubre el suelo y daña a los enemigos"},
	{"27", "", "Disparas en diagonal durante 60 segundos"},
	{"28", "", "Te hacen la mitad de daño en la habitación actual"},  --TODO
	{"29", "", "Te hace un corazón de daño en la habitación actual"}, --TODO
	{"30", "", "Genera una caca mientras caminas durante 4 segundos"}, --TODO
	{"31", "", "Efecto de Curse of the maze (Maldición del laberinto) en la planta actual"}, --TODO
	{"32", "", "Te haces mucho más grande#No afecta a la hitbox"},
	{"33", "", "Te haces mucho más pequeño#Tu hitbox se hace más pequeña"},
	{"34", "", "Genera 2 arañas azules por cada caca de la habitación"},
	{"35", "", "Genera 2 arañas azules por cada enemigo de la habitación#Genera de 2 a 6 arañas azules si no hay enemigos en la habitación"},
	{"36", "", "Efecto de invencibilidad breve#↑ {{Damage}} Daño +7#↑ {{Range}} Alcance +3#Dura en la habitación actual"},
	{"37", "", "Pixela la pantalla durante 30 segundos"},
	{"38", "", "Invoca 6 moscas azules"},
	{"39", "", "Genera una piscina de creep resbaladizo persistente"},
	{"40", "", "Genera una piscina de creep ralentizante persistente"},
	{"41", "", "Ralentiza a todos los enemigos de la habitación"}, --TODO
	{"42", "", "Acelera a todos los enemigos de la habitación"}, --TODO
	{"43", "", "Consume el trinket actual y ganas su efecto de manera permanente"}, --TODO
	{"44", "", "Dispara un grupo de lágrimas de {{Collectible149Ipecac"},
	{"45", "", "Invencibilidad corta#Asusta a todos los enemigos#Comerse dos enemigos repone medio corazón"},
	{"46", "", "Genera la última píldora usada como una píldora para caballos"},
	{"47", "", "↓ {{Shotspeed}} Vel. de tiro -0.3"},
	{"48", "", "↑ {{Shotspeed}} Vel. de tiro +0.3"},
	{"49", "", "↑ Aumenta una estadística aleatoria dos veces#↓ Disminuye otra estadística aleatoria dos veces#Si tienes PHD no disminuye nada"},
	[9999] = {"", "Píldora dorada", "Efecto de píldora de caballo aleatorio#Se destruye tras unos cuantos usos"}, -- Píldora dorada
}

---------- Glitched Items Descriptions ----------
EID.descriptions[languageCode].GlitchedItemText = {
	-- This will be appended to words to pluralize them, make it "" to not pluralize
	pluralize = "s",
		
	-- Item Config info
	AddBlackHearts = "{1} Corazón/zones negro/s",
	AddBombs = "{1} Bomba/s",
	AddCoins = "{1} Moneda/s",
	AddHearts = "Cura {1} Corazón/es rojo/s",
	AddKeys = "{1} Llave/s",
	AddMaxHearts = "{1} Contendor/es de Corazón",
	AddSoulHearts = "{1} Corazón/zones de alma",
	
	-- Cache Flag names
	cacheFlagStart = "Puede afectar ",
	[0] = "{{Damage}} Daño", "{{Tears}} Lágrimas", "{{Shotspeed}} Vel. de tiro", "{{Range}} Alcance", "Velocidad", "Efectos de lágrima", "Color de lágrima", "Vuelo", "Tipo de ataque", "Familiares", "Suerte", "Tamaño", "Color", "Contenido de cofres", [16] = "Todas las estadísticas",
	
	-- Attribute triggers
	chain = "Que: ",
	active = "Al usarse:#",
	pickup_collected = "Al tomar un recolectable:#", --chance to?
	enemy_kill = "Al matar, Posibilidad de:#",
	damage_taken = "Al recibir daño:#", --chance to?
	entity_spawned = "Cuando un {{ColorGray}}{T1}{{ColorText}} Se genera:#",
	tear_fire = "Al disparar una lágrima, posibilidad de:#",
	enemy_hit = "Al golpear un enemigo, posibilidad de:#",
	room_clear = "Al limpiar una sala:#", --chance to?
	
	-- Attribute effects
	area_damage = "Hace {1} de daño en el área", 
	add_temporary_effect = "Gana {1} Durante la sala",
	convert_entities = "Convierte todos los {{ColorGray}}{1}{{ColorText}} de la sala en {{ColorGray}}{2}{{ColorText}}",
	use_active_item = "Usa {1}",
	spawn_entity = "Genera un {{ColorGray}}{1}{{ColorText}}",
	fart = "Suelta un pedo de tamaño {1}",
	
	-- Generic entity names not obtained from entities2.xml
	-- This could also be a place to localize entity names; this table is read from before EID.XMLEntityNames
	["4.-1"] = "lit Bomb",
	["5.0"] = "pickup",
	["5.10"] = "Heart",
	["5.20"] = "Coin",
	["5.30"] = "Key",
	["5.40"] = "Bomb pickup",
	["5.69"] = "Grab Bag",
	["5.70"] = "Pill",
	["5.90"] = "Battery", 
	["5.300"] = "Card",
	["9.-1"] = "enemy projectile",
	["999.-1"] = "grid object",
	["1000.0"] = "effect",	
}

---------- Misc. Text ----------
-- Void stuff
EID.descriptions[languageCode].VoidNames = {"de Velocidad {{Speed}}", "de Lágrimas {{Tears}}", "de Daño {{Damage}}", "de Alcance {{Range}}", "de Vel. de tiro {{Shotspeed}}", "de Suerte {{Luck}}"}
EID.descriptions[languageCode].VoidShopText = "Si se absorbe justo después de tomarlo, ganarás:"
EID.descriptions[languageCode].VoidOptionText = " Será absorbido en su lugar"
-- Void stuff end

-- Bag of Crafting stuff
EID.descriptions[languageCode].CraftingBagContent = "Bolsa:"
EID.descriptions[languageCode].CraftingRoomContent = "Sala:"
EID.descriptions[languageCode].CraftingFloorContent = "Piso:"

EID.descriptions[languageCode].CraftingBagQuality = "Calidad:"
EID.descriptions[languageCode].CraftingBestQuality = "Mejor Calidad:"

EID.descriptions[languageCode].CraftingHideKey = "Ocultar:"
EID.descriptions[languageCode].CraftingPreviewKey = "Prevista:"
EID.descriptions[languageCode].CraftingPreviewBackup = "!!! Si este objeto está bloqueado, se convertirá en"

EID.descriptions[languageCode].CraftingBagModError = "!!! {{ColorRed}}ERROR:#{{ColorRed}}El \"Cálculo de Recetas\" actualmente no funciona con mods que añaden objetos!#{{ColorRed}}Por favor desinstala los mods de objetos o desactiva las descripciones de Bag of Crafting en la configuración"
EID.descriptions[languageCode].CraftingResults = "(Desplazar: mantén {{CONFIG_BoC_Toggle}} + {{ButtonY}} {{ButtonA}},#Bloquear: {{ButtonX}}, Refrescar: {{ButtonB}})"
-- Bag of Crafting stuff end

-- Mimic items charges
EID.descriptions[languageCode].BlankCardCharge = "Cargas de Carta en Blanco:" 
EID.descriptions[languageCode].BlankCardQCard = "Te teletransporta a la habitación de I Am Error#Tanto Carta en blanco como la ¿? carta se destruirán" 
EID.descriptions[languageCode].ClearRuneCharge = "Cargas de Runa limpia:" 
EID.descriptions[languageCode].PlaceboCharge = "Cargas de Placebo:" 
-- Mimic items charges end

-- Warnings
EID.descriptions[languageCode].AchievementWarningTitle = "{{ColorYellow}}!!! ADVERTENCIA !!!"
EID.descriptions[languageCode].AchievementWarningText = "¡Los logros están deshabilitados!#Para poder progresar en el juego, primero debes vencer a Mamá (Depths II) sin mods habilitados.#(Si ya derrotaste a Mamá, este mensaje es un bug, ignóralo)#(Este aviso puede ser desactivado en la configuración)"
EID.descriptions[languageCode].OutdatedModWarningText = "¡Un mod sin actualizar está reduciendo la cantidad de objetos! Esto puede causar crasheos, especialmente al entrar al area de la Pieza del cuchillo 2#Por favor, desinstala los mods con el archivo resources/items.xml desactualizado"
EID.descriptions[languageCode].OldGameVersionWarningText = "Tu versión de Repentance no es la más reciente#La versión más reciente es la única con soporte oficial#(Este aviso puede ser desactivado en la configuración)"
EID.descriptions[languageCode].ModdedRecipesWarningText = "Los objetos modeados pueden provocar cálculos incorrectos#Usa el modo No Recipes o desactiva el cálculo de la Bolsa de trabajo si es que los cálculos son incorrectos#(Este aviso puede ser desactivado en la configuración)"
-- Warnings end

-- False PHD modifier
EID.descriptions[languageCode].FalsePHDHeart = "Genera {{BlackHeart}} 1 corazón negro"
EID.descriptions[languageCode].FalsePHDDamage = "{{Damage}} Daño +0.6"
EID.descriptions[languageCode].FalsePHDHorseDamage = "{{Damage}} Daño +1.2"
-- False PHD modifier end

EID.descriptions[languageCode].FlipItemToggleInfo = "(Mantén presionado {{ButtonSelect}} para mostrar la descripción)"

EID.descriptions[languageCode].MCM = {
	DemoObjectName = "Nombre de objeto demostrativo",
	DemoObjectTransformation = "Transformación demostrativa",
	DemoObjectText = "Este texto está en español#¡Una larga y genial descripción para demostrar los saltos de línea causados por la anchura de texto de EID!#\1 Esta linea también es genial#Esta linea te ama {{Heart}}",
} 

-- If Debug enabled, add overwrite tables to the languagepack in order for the language completion script to be able to compare them
if EID.enableDebug then
	EID.descriptions[languageCode].repCollectibles = repCollectibles
	EID.descriptions[languageCode].repTrinkets = repTrinkets
	EID.descriptions[languageCode].repCards = repCards
	EID.descriptions[languageCode].repPills = repPills
end
